# IPL (Indian Premier League) Rulebook v1 (data-backed)

**Data:** IPL ke 1243 match, 18 Apr 2008 se 31 May 2026 tak (19 season). Source: Cricsheet ball-by-ball (aapki `ipl_json.zip`). Har number code se gina gaya hai.
**Decided:** natija aaya, DLS nahi laga, poore 20 over ka target tha. Aise **1185 match** hain. No result 9, DLS 23, super over tie 16.
**Abhi ki 10 teams:** Chennai Super Kings (CSK), Mumbai Indians (MI), Kolkata Knight Riders (KKR), Royal Challengers Bengaluru (RCB), Rajasthan Royals (RR), Sunrisers Hyderabad (SRH), Punjab Kings (PBKS), Delhi Capitals (DC), Gujarat Titans (GT, 2022 se), Lucknow Super Giants (LSG, 2022 se).
**Purane naam ek team mein jode gaye:** Delhi Daredevils = Delhi Capitals, Kings XI Punjab = Punjab Kings, Royal Challengers Bangalore = Bengaluru. Deccan Chargers alag team hai (SRH nahi). Band ho chuki teams: Deccan Chargers, Kochi, Pune Warriors, Gujarat Lions, Rising Pune Supergiant.
**Home ground:** MI = Wankhede, KKR = Eden Gardens, CSK = Chepauk, RCB = Chinnaswamy, DC = Arun Jaitley (Kotla), SRH = Uppal, RR = Sawai Mansingh (Jaipur) aur Guwahati, PBKS = Mohali, Mullanpur aur Dharamsala, GT = Narendra Modi (Ahmedabad), LSG = Ekana. **2020 (UAE) aur 2022 (sirf Mumbai/Pune) mein kisi ko home nahi gina.**
**Champions:** 2008 RR, 2009 Deccan, 2010 CSK, 2011 CSK, 2012 KKR, 2013 MI, 2014 KKR, 2015 MI, 2016 SRH, 2017 MI, 2018 CSK, 2019 MI, 2020 MI, 2021 CSK, 2022 GT, 2023 CSK, 2024 KKR, 2025 RCB, 2026 RCB.
**Sabse zaroori baat:** 2023 se **Impact Player rule** aaya aur score bahut badh gaye. Average pehli innings 2022 mein 171 thi, 2026 mein 196. Is liye is rulebook mein **2023 se (Impact Player daur) ke numbers ko zyada wazan** diya gaya hai.
**Teen tab:** Rulebook, Data Book, aur Live Calculator.

---
## Bet kaise chunein (har haalat mein ek bet)
Har screenshot par ek bet di jayegi. Bet neeche ke 4 rules mein se **pehle lagne wale** rule se chuni jaati hai. Live Calculator bhi yahi karta hai.

| Rule | Kab lagta hai | Kaunsi bet | Stake |
|---|---|---|---|
| **Jackpot Rule** | Underdog ka odds 3.5 ya zyada ho, aur model usay market se 7+ point zyada de | Underdog jeetega | Chhoti (normal ka 20-25%) |
| **Market Rule** | Model aur market mein 15+ point ka farq ho | Market ka favourite jeetega. Pichhle matches mein itne bade farq par market zyada sahi nikla | Chhoti (normal ka 25%) |
| **Value Rule** | Model kisi team ko market se 5-14 point zyada de | Woh team jeetegi | Neeche Stake Rule se |
| **Favourite Rule** | Model aur market ka farq 5 point se kam ho | Dono ka favourite jeetega | Neeche Stake Rule se |

**Stake Rule:** jis team par bet hai, model use 80%+ de to normal stake, 67-80% de to aadhi, aur us se kam de to chhoti (normal ka 25%). 25 paisa se kam ka favourite ho tab bhi stake normal se zyada nahi.
**Runs line (Over/Under):** data ka median line se jis taraf ho, usi taraf bet. Median line se 10+ run door ho to aadhi stake, warna chhoti.

---
## One-Side ya Jackpot: pehle se kaise pata chale
**IPL ke 810 match** (sirf poore over wale, DLS/no result bahar) ka test. Har match ka model andaza sirf us se pehle ke matches se bana.
- **One-side match:** jeetne wali team ne bade farq se jeeta (30+ run se defend, ya 7+ wicket se ya 3+ over pehle 5+ wicket ke saath chase).
- **Close match:** 10 ya kam run se, ya 2 ya kam wicket se, ya aakhri over mein faisla.
- **Jackpot:** jeetne wali team ka chance kisi waqt 25% ya kam tha.

**IPL mein:** one-side **44%**, close 35%, jackpot 25%. Innings break par 67%+ favourite 24% baar haara.

### 1. Toss ke baad: dono teams ki rating ka farq (Elo)
| Rating farq | Match | Taqatwar team jeeti | Taqatwar ne one-side jeeta | Close | Jackpot |
|---|---|---|---|---|---|
| 0-50 (barabar) | 486 | 49% | 23% | 32% | 26% |
| 50-100 | 236 | 53% | 26% | 36% | 22% |
| 100-150 | 47 | 49% | 21% | 51% | 32% |
| 150-250 | 4 | 75% | 50% | 50% | 0% |

### 2. Innings break par model ka %
| Favourite ka % | Match | Favourite jeeta | Favourite ne one-side jeeta | Close | Jackpot |
|---|---|---|---|---|---|
| 50-60% | 224 | 54% | 19% | 45% | 30% |
| 60-70% | 188 | 69% | 32% | 42% | 26% |
| 70-80% | 185 | 71% | 29% | 34% | 28% |
| 80-90% | 146 | 79% | 41% | 27% | 23% |
| 90%+ | 67 | 91% | 82% | 6% | 8% |

### 3. Pehli innings ka score, ground ke average ke muqable
| Score | Match | Chase jeeta | One-side | Close | Jackpot |
|---|---|---|---|---|---|
| Ground avg se 25+ kam | 126 | 86% | 58% | 21% | 17% |
| 10-25 kam | 99 | 74% | 37% | 37% | 30% |
| Avg ke 10 run andar | 216 | 61% | 41% | 45% | 28% |
| 10-25 zyada | 136 | 51% | 37% | 46% | 28% |
| 25+ zyada | 233 | 28% | 47% | 26% | 24% |

### 4. Chase ke 6 over par (zaroori rate se aage ya peeche, kitne wicket gire)
| Haalat | Match | Chase jeeta | Chase ne one-side jeeta | Defend ne one-side jeeta | Jackpot |
|---|---|---|---|---|---|
| Aage, 0-1 wkt | 256 | 84% | 49% | 2% | 24% |
| Aage, 2 wkt | 77 | 71% | 31% | 5% | 22% |
| Aage, 3+ wkt | 26 | 50% | 23% | 19% | 27% |
| Peeche, 0-1 wkt | 185 | 52% | 24% | 16% | 28% |
| Peeche, 2 wkt | 134 | 29% | 7% | 31% | 25% |
| Peeche, 3+ wkt | 132 | 20% | 2% | 45% | 26% |

### 5. Milay-jule nishan
| Haalat | Match | Favourite jeeta | Favourite one-side | Jackpot | Favourite haara |
|---|---|---|---|---|---|
| ONE-SIDE signal: model 80%+ aur wahi team rating mein 100+ aage | 9 | 78% | 56% | 22% | 22% |
| Model 80%+ lekin rating mein doosri team aage | 44 | 89% | 54% | 11% | 11% |
| Model 80%+ aur favourite chase kar raha | 102 | 87% | 61% | 14% | 13% |
| Model 80%+ aur favourite defend kar raha | 111 | 78% | 48% | 22% | 22% |
| JACKPOT signal: model 67-80%, favourite defend, underdog h2h aage | 53 | 68% | 23% | 21% | 32% |
| Model 67-80%, favourite defend | 129 | 67% | 29% | 22% | 33% |
| Model 67-80%, favourite chase | 128 | 75% | 34% | 29% | 25% |
| Barabar rating (farq 50 se kam) + model 60% se kam | 150 | 52% | 17% | 27% | 48% |

### 6. Rules: one-side kab, jackpot kab
**ONE-SIDE ke nishan (favourite par normal stake, aur margin/runs line bhi favourite ki taraf):**
1. **Model 90%+ (innings break):** favourite 91% jeeta, aur 82% baar one-side. Close sirf 6%.
2. **Score ground average se bahut kam (Ground avg se 25+ kam):** chase 86% jeeta, 58% one-side.
3. **Score ground average se bahut zyada (25+ zyada):** defend 72% jeeta, 47% one-side.
4. **Chase 6 over par rate se aage aur 0-1 wicket:** chase 84% jeeta, 49% one-side, aur jackpot 24%.
5. **Chase 6 over par rate se peeche aur 3+ wicket:** defend 80% jeeta, defend ne 45% one-side jeeta.
6. **Rating se one-side ka pata nahi chalta:** league teams ki rating qareeb hoti hai. 100-150 farq par bhi taqatwar team sirf 49% jeeti. Is liye toss ke baad one-side ki bet mat socho, innings break ka intezar karo.

**JACKPOT ke nishan (favourite par sirf chhoti stake, underdog ka odds 3+ ho to Jackpot Catch side bet):**
1. **Model 70-80% wala favourite:** 29% haara, jackpot 28%. **"4 mein se 1" yahi hai.**
2. **Score ground average ke qareeb (Avg ke 10 run andar):** close 45%, jackpot 28%. Sabse kam one-side yahi hota hai.
3. **Model 67-80% aur favourite defend kar raha:** favourite 33% haara (chase wala favourite 25%).
4. **Rating barabar (farq 50 se kam) aur model 60% se kam:** one-side sirf 17%. Yeh coin-flip match hai, chhoti stake.

**Sab leagues mila kar (2174 match):** one-side 46%, close 32%, jackpot 24%. Model 90%+ par favourite 78% one-side jeeta. Model 70-80% par jackpot 26%.

**Sachchi baat:** sirf toss ke baad one-side ya jackpot ka andaza kamzor hai (league teams ki rating qareeb hoti hai). **Asli pata innings break aur chase ke pehle overs mein chalta hai.** Puri list Data Book ki "One-Side / Jackpot" sheet mein hai.

---
## Pakki Bet System (toss ke baad aur innings break ke baad)
Yeh system 6 league (BBL, ILT20, BPL, SA20, PSL, IPL) ke **2148 match** par test kiya gaya. Har match ka andaza sirf us se **pehle** ke matches se banaya gaya, phir asal natije se milaya gaya. Neeche ke % wahi hain jo asal mein sahi nikle.

**Sachchi baat:** koi system 100% nahi. Har league mein 4 mein se 1 match palat jata hai. Lekin bet ki **taqat** pehle se pata chal sakti hai. Calculator har bet ke saath taqat likhta hai.

### 1. Toss ke baad (match shuru hone se pehle)
Model: team rating (Elo) + aakhri 5 match + head to head + ground ka chase record.

| Model ka % | Sab league: match | Sahi nikli | IPL: match | Sahi nikli |
|---|---|---|---|---|
| 50-60% | 1807 | 53.7% | 607 | 52.9% |
| 60-70% | 329 | 55.3% | 141 | 51.1% |
| 70-80% | 12 | 58.3% | 4 | 75.0% |
| 80-90% | 0 | - | 0 | - |
| 90%+ | 0 | - | 0 | - |

- **Toss ke baad andaza sirf 54.0% sahi nikla** (IPL mein 52.7%). T20 mein match se pehle koi team 60% se zyada pakki nahi hoti.
- **Toss Bet Rule:** toss ke baad bet hamesha **chhoti stake** par. Badi bet innings break ke liye bachao.

### 2. Innings break ke baad (sabse mazboot waqt)
Model: target + ground ka average + team rating + aakhri 5 + toss + playoff.

| Model ka % (jis team par bet) | Taqat | Sab league: match | Sahi nikli | IPL: match | Sahi nikli |
|---|---|---|---|---|---|
| 50-60% | COIN-FLIP BET | 587 | 54.2% | 212 | 52.4% |
| 60-70% | KAMZOR BET | 528 | 64.4% | 174 | 63.2% |
| 70-80% | THEEK BET | 482 | 74.1% | 170 | 73.5% |
| 80-90% | MAZBOOT BET | 371 | 85.7% | 136 | 82.4% |
| 90%+ | PAKKI BET | 180 | 93.3% | 60 | 91.7% |

- Innings break par andaza **69.9% sahi** nikla (IPL mein 68.2%). 2024 se ke matches mein 72.4%.
- **Model 90%+ = PAKKI BET** (93% sahi), **80-90% = MAZBOOT BET** (86% sahi). Sab matches mein se taqreeban **4 mein se 1 match** is darje tak pahunchta hai.
- **70-80% = THEEK BET** (74%), **60-70% = KAMZOR BET** (64%), **50-60% = COIN-FLIP** (54%).

### 3. Chase ke dauran (live)
Live model har ball par check kiya gaya: model 90%+ kahe to chase karne wali asal mein ~96-97% jeeti, 80-90% kahe to ~85%.

### 4. Odds aur data ko milao (Pakki Bet ki aakhri shart)
| Data (model) | Odds (market) | Faisla |
|---|---|---|
| PAKKI ya MAZBOOT | Market ka favourite bhi yahi team | **Sabse mazboot bet.** Normal stake. |
| PAKKI ya MAZBOOT | Market doosri team ko favourite maanta hai | Market Rule lagta hai (15+ farq ho to). Stake chhoti. |
| THEEK ya kam | Koi bhi | Stake chhoti ya aadhi. |
| Underdog odds 3.5+, model 7+ point zyada | - | Jackpot Rule, chhoti stake. |

**Odds par ek zaroori baat:** PAKKI BET ka odds aksar 1.10-1.20 hota hai. 93% sahi bet par 1.10 odds ka matlab: 10 mein se 1 haar pichhli 9 jeet ka munafa le jati hai. **Isliye calculator "sahi rate" bhi batata hai.** Market ka odds sahi rate se zyada ho tab hi asli faayda hai.

### 5. Har match par yeh tarteeb
1. **Toss ke baad:** calculator ka "Toss ke baad" mode. Bet hamesha chhoti.
2. **Innings break:** "Innings break" mode mein target daalo. PAKKI/MAZBOOT aur market ek taraf = normal stake.
3. **Chase ke dauran:** "Chase live" mode. Model 90%+ ho aur market ek taraf ho to PAKKI BET.
4. Calculator ki likhi taqat aur "sahi nikli %" dekh kar hi stake chuno.

---
## Jackpot Catch: favourite 50 paisa ya kam par ho to underdog kab pakdo
Jab favourite ka rate 50 paisa ya kam ho (odds 1.50 ya kam, yani favourite 67%+), to underdog ka odds 3 ya zyada hota hai. Sawal yeh hai: **kis situation mein underdog utni baar jeetta hai jitna odds kehte hain, ya us se zyada?** Wahi jackpot pakadne ki jagah hai.
**Kaise check kiya:** underdog ka odds model ke sahi rate par maana. "100 lagao to" column batata hai ke har aisi situation mein 100-100 ki bet lagate to aakhir mein kitna faayda ya nuksaan hota. **Asal market mein bookie ka hissa (5-8%) bhi katta hai, is liye sirf +10% se zyada wali situation asli faayde ki hai.**

### 1. Innings break par (6 league, 1206 match)
| Situation | Match | Odds ke hisaab se underdog ka chance | Asal mein underdog jeeta | Average underdog odds | 100 lagao to faayda/nuksaan |
|---|---|---|---|---|---|
| Sab (favourite 67%+) | 1206 | 20% | 20% | 5.0 | +1% |
| Favourite 67-80% (25-50 paisa) | 655 | 27% | 27% | 3.7 | +2% |
| Favourite 80-90% (11-25 paisa) | 370 | 15% | 14% | 6.5 | -3% |
| Favourite 90%+ (11 paisa se kam) | 181 | 6% | 7% | 17.2 | +9% |
| Underdog CHASE kar raha (favourite defend) | 538 | 21% | 24% | 4.7 | +19% |
| Underdog DEFEND kar raha (favourite chase) | 668 | 19% | 18% | 5.2 | -13% |
| Underdog chase + favourite 80%+ | 219 | 13% | 15% | 7.7 | +33% |
| Underdog defend + favourite 80%+ | 332 | 12% | 10% | 8.5 | -20% |
| Underdog head to head mein aage | 504 | 21% | 23% | 4.8 | +13% |
| Underdog ne toss jeeta | 544 | 21% | 22% | 4.8 | +6% |
| Underdog ke aakhri 5 behtar | 362 | 21% | 21% | 4.8 | -9% |
| Underdog ki rating zyada | 471 | 21% | 19% | 4.8 | -17% |
| Underdog chase + h2h aage | 232 | 22% | 26% | 4.5 | +25% |
| Underdog chase + toss jeeta | 376 | 21% | 24% | 4.7 | +15% |
| Playoff | 100 | 22% | 17% | 4.5 | -40% |

**IPL league:**
| Situation | Match | Odds ke hisaab se underdog ka chance | Asal mein underdog jeeta | Average underdog odds | 100 lagao to faayda/nuksaan |
|---|---|---|---|---|---|
| IPL: underdog chase | 206 | 21% | 25% | 4.8 | +27% |
| IPL: underdog defend | 226 | 20% | 19% | 5.1 | +5% |

### 2. Live chase ke dauran (BPL, SA20, PSL, IPL ki har over, underdog 33% ya kam)
| Situation | Match | Odds ke hisaab se underdog ka chance | Asal mein underdog jeeta | Average underdog odds | 100 lagao to faayda/nuksaan |
|---|---|---|---|---|---|
| Sab (live, underdog 33% ya kam) | 7728 | 16% | 16% | 6.4 | -11% |
| Underdog CHASE kar raha | 3536 | 15% | 16% | 6.6 | -14% |
|   Underdog CHASE kar raha, PP (1-6) | 851 | 22% | 25% | 4.6 | +22% |
|   Underdog CHASE kar raha, Beech (7-12) | 884 | 18% | 17% | 5.6 | -14% |
|   Underdog CHASE kar raha, Late (13-16) | 895 | 13% | 12% | 7.5 | -35% |
|   Underdog CHASE kar raha, Death (17-20) | 906 | 8% | 9% | 12.3 | -26% |
|   Underdog CHASE kar raha, chase team ke 8-10 wkt haath mein | 1106 | 21% | 24% | 4.7 | +12% |
|   Underdog CHASE kar raha, chase team ke 6-7 wkt | 1056 | 18% | 17% | 5.7 | -17% |
|   Underdog CHASE kar raha, chase team ke 4-5 wkt | 859 | 11% | 11% | 9.0 | -27% |
|   Underdog CHASE kar raha, chase team ke 1-3 wkt | 515 | 4% | 5% | 25.8 | -40% |
|   Underdog CHASE kar raha, pichhla over 12+ run | 490 | 13% | 15% | 7.9 | -13% |
|   Underdog CHASE kar raha, pichhle over mein wicket | 1678 | 16% | 17% | 6.2 | -2% |
|   Underdog CHASE kar raha, aam over | 1368 | 15% | 15% | 6.7 | -28% |
| Underdog DEFEND kar raha | 4192 | 16% | 17% | 6.3 | -9% |
|   Underdog DEFEND kar raha, PP (1-6) | 1110 | 21% | 24% | 4.7 | +11% |
|   Underdog DEFEND kar raha, Beech (7-12) | 1111 | 18% | 18% | 5.7 | -9% |
|   Underdog DEFEND kar raha, Late (13-16) | 1090 | 14% | 14% | 7.3 | -20% |
|   Underdog DEFEND kar raha, Death (17-20) | 881 | 10% | 10% | 10.3 | -22% |
|   Underdog DEFEND kar raha, chase team ke 8-10 wkt haath mein | 2847 | 17% | 17% | 6.0 | -8% |
|   Underdog DEFEND kar raha, chase team ke 6-7 wkt | 1035 | 14% | 14% | 7.1 | -26% |
|   Underdog DEFEND kar raha, chase team ke 4-5 wkt | 288 | 16% | 19% | 6.3 | +26% |
|   Underdog DEFEND kar raha, chase team ke 1-3 wkt | 22 | 18% | 27% | 5.5 | +53% |
|   Underdog DEFEND kar raha, pichhla over 12+ run | 1234 | 18% | 17% | 5.7 | -11% |
|   Underdog DEFEND kar raha, pichhle over mein wicket | 548 | 13% | 16% | 7.4 | +7% |
|   Underdog DEFEND kar raha, aam over | 2410 | 16% | 17% | 6.4 | -12% |
| Underdog chase: 6+ wkt haath mein, RRR 10-12 | 915 | 20% | 21% | 4.9 | +2% |
| Underdog chase: 6+ wkt, RRR 12-14 | 382 | 15% | 14% | 6.6 | -6% |
| Underdog chase: 4-5 wkt, RRR 9-11 | 104 | 19% | 19% | 5.1 | -3% |
| Underdog chase: death, 5+ wkt, 15-30 chahiye | 39 | 17% | 23% | 5.8 | +52% |
| Underdog defend: chase ko RRR 7-8, 3-5 wkt haath mein | 54 | 18% | 19% | 5.7 | -3% |
| Underdog defend: chase ko RRR 8-9, 4-6 wkt | 122 | 21% | 20% | 4.8 | -1% |
| IPL: sab live | 4351 | 16% | 17% | 6.1 | -10% |

### 3. Jackpot Catch Rules
1. **Chase Underdog Rule:** innings break par jackpot **sirf chase karne wale underdog** par. Yahan underdog odds se zyada jeeta (+19%). Favourite 80%+ ho aur pehle bat kar chuka ho to aur behtar (+33%). Head to head mein underdog aage ho to +25%.
2. **Defend Underdog par jackpot nahi:** pehle batting wala underdog odds se kam jeeta (-13%, favourite 80%+ ho to -20%). Yahan favourite (chase) par hi bet.
3. **Powerplay Jackpot Rule:** live jackpot sirf **chase ke pehle 6 over** mein. Chase wala underdog +22%, defend wala underdog +11%.
4. **Late Jackpot nahi:** over 13 ke baad underdog par jackpot bet ghaate ki rahi (-20% se -35%). Wahan favourite par bet.
5. **Wicket haath mein:** chase wala underdog ke 8-10 wicket haath mein hon to +12%. 4-5 wicket bache hon to -27%.
6. **Death ka chhota mauqa:** death overs mein chase wala underdog, 5+ wicket haath mein, 15-30 run chahiye: +52%. Lekin sirf 39 match hain, sirf chhoti bet.
7. **League ka farq:** IPL (+27%) aur PSL (+39%) mein chase wala underdog sabse achha. SA20 mein nahi (-44%, sirf 20 match).
8. **Stake:** jackpot bet hamesha normal ka 10-25%. Aisi bet 4-5 mein se sirf 1 baar lagti hai. Jeet badi hoti hai, lekin beech mein lagatar haarein aayengi.
9. **Odds check:** calculator "JACKPOT CATCH" tabhi likhta hai jab underdog ka market odds model ke sahi rate se zyada ho.

---
## Palat Book: 4 mein se 1 match kaun sa palat'ta hai aur kyun
Yeh section 6 league ke **1033 match** par bana hai jahan innings break par kisi team ko model ne 70%+ diya. Har andaza sirf pehle ke matches se bana (asli test). Live hisse ke liye BPL, SA20, PSL aur IPL ke **1543 match** ki har ball dekhi gayi.
**Odds ka note:** purane matches ke asal market odds data mein nahi hain. Is liye "us waqt odds kya keh rahe the" ki jagah model ka % aur us ka sahi rate (paisa) diya gaya hai. Market aksar isi ke qareeb hota hai.

### 1. "4 mein se 1" asal mein kis par lagta hai
| Innings break par favourite ka % | Sab league: match | Palta | IPL: match | Palta | Matlab |
|---|---|---|---|---|---|
| 70-80% | 482 | 26% | 170 | 26% | har 4 mein se 1 |
| 80-90% | 370 | 14% | 136 | 18% | har 7 mein se 1 |
| 90%+ | 181 | 7% | 60 | 8% | har 15 mein se 1 |

- **"4 mein se 1" sirf 70-80% wale favourite par sach hai.** 80-90% wala 7 mein se 1 baar, 90%+ wala 15 mein se 1 baar palat'ta hai.
- Palatne wale matches mein favourite ka average 79% tha, jeetne walon mein 82%. **Palatne wala match pehle se thoda kamzor favourite hota hai,** lekin farq chhota hai.

**Live mein:** jo team kisi bhi waqt is % tak pahunchi, woh phir bhi kitni baar haari:

| Favourite kabhi pahuncha | Match | Phir bhi haara | % |
|---|---|---|---|
| 75%+ | 1909 | 385 | 20.2% |
| 80%+ | 1816 | 299 | 16.5% |
| 85%+ | 1714 | 204 | 11.9% |
| 90%+ | 1625 | 134 | 8.2% |
| 95%+ | 1518 | 62 | 4.1% |

### 2. Kaun sa favourite zyada palat'ta hai: chase wala ya defend wala
| Favourite ka % | Chase karne wala favourite palta | Defend karne wala favourite palta |
|---|---|---|
| 70-80% | 25% (246) | 27% (236) |
| 80-90% | 13% (210) | 16% (160) |
| 90%+ | 4% (122) | 12% (59) |

- **Sabse saaf nishan: defend karne wala favourite zyada palat'ta hai.** 90%+ par chase wala sirf 4% palta, defend wala 12% (3 guna).
- **Defend Favourite Rule:** pehle batting wali team favourite ho to us ki taqat ek darja kam samjho (PAKKI ko MAZBOOT, MAZBOOT ko THEEK). Calculator yeh khud karta hai.

### 3. Innings break par khatre ke nishan (70%+ favourite)
| Nishan | Nishan ho to palta (match) | Nishan na ho to palta (match) |
|---|---|---|
| Underdog ki team rating (Elo) favourite se zyada | 16.5% (395) | 19.6% (638) |
| Underdog ke aakhri 5 match favourite se behtar | 18.1% (298) | 18.5% (735) |
| Underdog head to head mein aage | 21.0% (414) | 16.6% (619) |
| Underdog apne ghar par | 16.2% (179) | 18.9% (854) |
| Underdog ne toss jeeta | 20.1% (467) | 17.0% (566) |
| Playoff / Final | 9.8% (82) | 19.1% (951) |
| Season ke pehle 8 match | 18.3% (186) | 18.4% (847) |
| Target ground average ke 10 run ke andar (par score) | 33.3% (30) | 17.9% (1003) |

**Sachchi baat:**
- **Underdog head to head mein aage (21% vs 17%) aur underdog ne toss jeeta (20% vs 17%)** thoda khatra badhate hain.
- **Underdog ki rating, aakhri 5 match, ghar aur season ki shuruaat se koi farq nahi** pada. Yeh cheezein model pehle hi gin leta hai.
- **Playoff mein favourite kam palta** (10%).
- Koi aisa chhupa nishan nahi mila jo pehle se bata de ke "yeh match palatega". **Palat ka sabse bada hissa qismat aur match ke andar ke waqiat hain.**

### 4. Palat kab shuru hota hai
Live mein favourite ka chance 50% se neeche kab gira: powerplay (1-6) 142 (46%), beech (7-15) 112 (36%), death (16-20) 55 (18%).
- **Har 2 mein se 1 palat chase ke pehle 6 over mein shuru hota hai.**
- **Powerplay Watch Rule:** innings break par bet ke baad chase ke 6 over par calculator dobara chalao. Favourite ka % 60 se neeche aa jaye to doosri team par chhoti bet (hedge) se nuksaan kam hota hai.

### 5. Palat ke waqt kya hota hai (live waqiat)
Jab **chase karne wali** 75%+ favourite thi, aur favourite rehte hue yeh hua, to aakhir mein kitni baar haari:

| Waqiya | Match | Haari |
|---|---|---|
| 18 ball mein 3 wicket | 116 | 24.1% |
| Sab match (chase favourite 75%+ bani) | 831 | 18.7% |
| 2 lagatar over mein 5 ya kam run | 454 | 18.3% |
| Set batsman (30+) out | 553 | 13.4% |
| Ek over mein 2+ wicket | 116 | 12.1% |

Jab **defend karne wali** 75%+ favourite thi:

| Waqiya | Match | Haari |
|---|---|---|
| 2 lagatar over mein 12+ run | 311 | 22.2% |
| Sab match (defend favourite 75%+ bani) | 712 | 21.6% |
| Ek over mein 5+ extra | 106 | 20.8% |
| Ek over mein 18+ run | 296 | 20.6% |
| 30+ run ki partnership 18 ball ke andar | 373 | 20.4% |

**Sachchi baat:**
- **Chase favourite ke 18 ball mein 3 wicket gire to 24% haari** (aam 19%). Yeh sabse saaf live nishan hai.
- Baaki waqiat (set batsman out, 18+ run ka over, extras) jeetne wale matches mein bhi utne hi hote hain. **Ek akela waqiya palat ki pakki nishani nahi.** Live calculator har ball ke baad naya % deta hai, wahi sabse sahi paimana hai.
- Haar ke matches mein kya hua, us ki team-wise wajah upar Jackpot section mein hai.

### 6. IPL ke aakhri palatne wale matches (innings break par 70%+ favourite haara)
| Date | Ground | Match | Favourite (haara) | Model ka % (sahi rate) |
|---|---|---|---|---|
| 2026-05-12 | Narendra Modi / Motera (Ahmedabad) | Gujarat Titans 168 v Sunrisers Hyderabad | **Sunrisers Hyderabad** (chase) | 78% (~28 paisa) |
| 2026-05-04 | Wankhede (Mumbai) | Lucknow Super Giants 228 v Mumbai Indians | **Lucknow Super Giants** (defend) | 73% (~36 paisa) |
| 2026-05-01 | Sawai Mansingh (Jaipur) | Rajasthan Royals 225 v Delhi Capitals | **Rajasthan Royals** (defend) | 81% (~24 paisa) |
| 2026-04-29 | Wankhede (Mumbai) | Mumbai Indians 243 v Sunrisers Hyderabad | **Mumbai Indians** (defend) | 86% (~16 paisa) |
| 2026-04-28 | Mullanpur (New Chandigarh) | Punjab Kings 222 v Rajasthan Royals | **Punjab Kings** (defend) | 78% (~28 paisa) |
| 2026-04-25 | Arun Jaitley / Kotla (Delhi) | Delhi Capitals 264 v Punjab Kings | **Delhi Capitals** (defend) | 93% (~7 paisa) |
| 2026-04-25 | Sawai Mansingh (Jaipur) | Rajasthan Royals 228 v Sunrisers Hyderabad | **Rajasthan Royals** (defend) | 77% (~30 paisa) |
| 2026-04-22 | Ekana (Lucknow) | Rajasthan Royals 159 v Lucknow Super Giants | **Lucknow Super Giants** (chase) | 82% (~22 paisa) |
| 2026-04-07 | Barsapara (Guwahati) | Rajasthan Royals 150 v Mumbai Indians | **Mumbai Indians** (chase) | 86% (~16 paisa) |
| 2025-05-27 | Ekana (Lucknow) | Lucknow Super Giants 227 v Royal Challengers Bengaluru | **Lucknow Super Giants** (defend) | 77% (~29 paisa) |
| 2025-04-28 | Sawai Mansingh (Jaipur) | Gujarat Titans 209 v Rajasthan Royals | **Gujarat Titans** (defend) | 71% (~40 paisa) |
| 2025-04-15 | Mullanpur (New Chandigarh) | Punjab Kings 111 v Kolkata Knight Riders | **Kolkata Knight Riders** (chase) | 96% (~4 paisa) |

Puri list Data Book ki **"Palat: Innings Break"** sheet mein hai aur har ball wali list "Palat: Live" sheet mein.

### 7. Palat se bachne ke rules (khulasa)
1. **Taqat dekho:** 70-80% wala favourite har 4 mein se 1 baar palat'ta hai. Is par hamesha chhoti ya aadhi stake.
2. **Defend Favourite Rule:** pehle batting wala favourite ek darja kamzor.
3. **Head to head aur toss:** underdog h2h mein aage ho aur toss bhi jeeta ho to stake ek darja kam.
4. **Powerplay Watch Rule:** chase ke 6 over par dobara check, 60% se neeche gira to hedge.
5. **Wicket Cluster Rule:** chase favourite ke 18 ball mein 3 wicket = khatra, doosri team ka odds 3.5+ ho to Jackpot Rule.
6. **Market ke saath:** data PAKKI kahe aur market ka favourite bhi wahi ho, tab hi normal stake.

---
## 0. Prediction ka tareeka (step by step)
1. **Innings break par** target band dekho (section 2). **Impact Player daur mein 185 aur 200 ki line sabse zaroori hai.**
2. **Ground dekho** (section 5). Uppal aur Ahmedabad mein bada score bachta hai, Delhi, Chennai, Lucknow aur Bengaluru mein abhi chase chal raha hai.
3. **Toss dekho** (section 3). Toss jeet kar field karne wali aage hai.
4. **Team aur head to head** (section 6-7). RCB abhi sabse mazboot.
5. **Live:** projection (section 11) aur chase grid (section 12). Calculator yeh khud karta hai.
6. **Market se milao aur bet chuno** ("Bet kaise chunein" section). 15+ point ka farq ho to market ke favourite par chhoti bet.

---
## 1. Overview: IPL chase karne walon ki league hai

| Period | Decided match | Pehle batting jeeti | Chase jeeta | Avg 1st inn | Toss winner jeeta |
|---|---|---|---|---|---|
| Sab (2008-2026) | 1185 | 45.5% | 54.5% | 169.7 | 51.5% |
| 2025 se | 138 | 42.0% | 58.0% | 194.4 | 56.5% |
| 2026 se | 70 | 35.7% | 64.3% | 196.4 | 52.9% |

| Season | Match | Decided | Avg 1st inn | Chase% | 200+ total | Champion | Pitch type (aapki script ke hisaab se) |
|---|---|---|---|---|---|---|---|
| 2008 | 58 | 54 | 163.3 | 61.1% | 7 | Rajasthan Royals | Balanced |
| 2009 | 57 | 53 | 150.3 | 52.8% | 1 | Deccan Chargers | Slow / Bowling |
| 2010 | 60 | 59 | 165.3 | 47.5% | 5 | Chennai Super Kings | Balanced |
| 2011 | 73 | 69 | 155.6 | 53.6% | 4 | Chennai Super Kings | Balanced |
| 2012 | 74 | 73 | 158.4 | 53.4% | 4 | Kolkata Knight Riders | Balanced |
| 2013 | 76 | 73 | 157.0 | 50.7% | 4 | Mumbai Indians | Balanced |
| 2014 | 60 | 57 | 163.9 | 63.2% | 5 | Kolkata Knight Riders | Balanced |
| 2015 | 59 | 52 | 167.4 | 42.3% | 6 | Mumbai Indians | Balanced |
| 2016 | 60 | 56 | 164.3 | 67.9% | 4 | Sunrisers Hyderabad | Balanced |
| 2017 | 59 | 57 | 166.7 | 54.4% | 8 | Mumbai Indians | Balanced |
| 2018 | 60 | 57 | 172.1 | 54.4% | 11 | Chennai Super Kings | Balanced |
| 2019 | 60 | 57 | 168.3 | 61.4% | 8 | Mumbai Indians | Balanced |
| 2020 | 60 | 56 | 169.2 | 51.8% | 8 | Mumbai Indians | Balanced |
| 2021 | 60 | 59 | 159.3 | 62.7% | 6 | Chennai Super Kings | Balanced |
| 2022 | 74 | 74 | 171.1 | 50.0% | 13 | Gujarat Titans | Balanced |
| 2023 | 74 | 71 | 183.0 | 45.1% | 23 | Chennai Super Kings | Batting Friendly |
| 2024 | 71 | 70 | 190.1 | 51.4% | 26 | Kolkata Knight Riders | Batting Friendly |
| 2025 | 74 | 68 | 192.4 | 51.5% | 32 | Royal Challengers Bengaluru | Batting Friendly |
| 2026 | 74 | 70 | 196.4 | 64.3% | 37 | Royal Challengers Bengaluru | Batting Friendly |

**Sabak:**
- **IPL mein chase karne wali team zyada jeetti hai** (54.5%). **2026 mein chase 64% jeeta.**
- **Score ka toofan:** 2022 mein 13 baar 200+ bana, 2026 mein 37 baar. 2023 se har season "Batting Friendly" (175+).
- Purane season (2008-2022) ke numbers ab kam kaam ke hain. Faisla 2023 se ke data par lo.

---
## 2. Innings break: target se chase ka chance (sabse zaroori table)

| 1st innings total | n | Chase% sab | n 2025+ | Chase% 2025+ | n 2026+ | Chase% 2026+ |
|---|---|---|---|---|---|---|
| 140 tak | 208 | 82.2% | 6 | 83.3% | 2 | 100.0% |
| 141-155 | 172 | 75.0% | 13 | 100.0% | 8 | 100.0% |
| 156-170 | 238 | 56.3% | 19 | 89.5% | 11 | 81.8% |
| 171-185 | 212 | 50.9% | 15 | 73.3% | 4 | 100.0% |
| 186-200 | 153 | 37.9% | 18 | 55.6% | 9 | 66.7% |
| 201-220 | 125 | 28.0% | 35 | 45.7% | 17 | 58.8% |
| 221+ | 77 | 14.3% | 32 | 25.0% | 19 | 31.6% |

**Impact Player daur (2023-2026, 282 decided match):**

| 1st innings total | n | Chase% |
|---|---|---|
| 155 tak | 46 | 84.8% |
| 156-170 | 36 | 75.0% |
| 171-185 | 46 | 63.0% |
| 186-200 | 42 | 50.0% |
| 201-220 | 59 | 39.0% |
| 221-240 | 32 | 18.8% |
| 241+ | 21 | 19.0% |

### Formula (calculator ke liye, 2023 se ke data par)
**z = 0.41 - 0.63 x (T - 180)/20**, chance = 1/(1+e^-z). Iske upar ground, team aur playoff ka adjustment lagta hai (section 15).

| T (1st inn) | 150 | 160 | 170 | 180 | 190 | 200 | 210 | 220 | 230 | 240 |
|---|---|---|---|---|---|---|---|---|---|---|
| Chase % | **79%** | **74%** | **67%** | **60%** | **52%** | **45%** | **37%** | **30%** | **24%** | **19%** |

**185 Line Rule (Impact Player daur):**
- **185 tak ka target = chase karne wali team par bet.** 170 tak 80%, 171-185 par 63% chase hua. 2025 se 156-170 par 90% chase hua.
- **186-200 = coin-flip (50%).** Yahan ground, toss aur team dekh kar calculator se Value Rule ya Favourite Rule chuno, chhoti stake.
- **201-220 = defend side par bet** (chase 39%), aadhi stake. 2026 mein yahan chase 59% hua, is liye stake badi mat karo.
- **221+ = defend side par bet** (chase 19%, 2026 mein 32%).

---
## 3. Toss

| Period | Toss jeet kar | n | Kitni baar chuna | Toss winner jeeta |
|---|---|---|---|---|
| Sab | Pehle batting | 400 | 33.8% | 45.5% |
| Sab | Pehle bowling | 785 | 66.2% | 54.5% |
| 2025 se | Pehle batting | 24 | 17.4% | 45.8% |
| 2025 se | Pehle bowling | 114 | 82.6% | 58.8% |
| 2026 se | Pehle batting | 12 | 17.1% | 16.7% |
| 2026 se | Pehle bowling | 58 | 82.9% | 60.3% |

- **Toss Rule:** 2025 se toss jeetne wali 83% baar pehle bowling leti hai, aur **59-60% jeetti hai.** Toss jeet kar field karne wali par bet, chhoti stake.
- **2026 mein toss jeet kar pehle batting karne wali 12 mein se sirf 2 jeeti.** Aisi team ke khilaf bet.

---
## 4. Home aur away: IPL mein ghar ka faayda khatam

| Period | Home team wale match | Home team jeeti |
|---|---|---|
| Sab | 825 | 52.8% |
| 2025 se | 129 | 45.0% |
| 2026 se | 68 | 50.0% |

| Team | Home (jeet/match) | Home win% | Kisi aur ke ghar (jeet/match) | Win% | Neutral ground (jeet/match) | Win% | Home 2025+ (match) | Bahar 2025+ (match) |
|---|---|---|---|---|---|---|---|---|
| Chennai Super Kings | 55/84 | 65.5% | 40/82 | 48.8% | 53/99 | 53.5% | 38.5% (13) | 35.7% (14) |
| Deccan Chargers | 3/18 | 16.7% | 10/24 | 41.7% | 16/33 | 48.5% | - (0) | - (0) |
| Delhi Capitals | 40/93 | 43.0% | 38/90 | 42.2% | 51/94 | 54.3% | 25.0% (12) | 66.7% (12) |
| Gujarat Lions | 5/14 | 35.7% | 8/15 | 53.3% | 0/1 | 0.0% | - (0) | - (0) |
| Gujarat Titans | 17/30 | 56.7% | 17/28 | 60.7% | 13/19 | 68.4% | 60.0% (15) | 64.3% (14) |
| Kochi Tuskers Kerala | 2/5 | 40.0% | 3/6 | 50.0% | 1/3 | 33.3% | - (0) | - (0) |
| Kolkata Knight Riders | 57/100 | 57.0% | 44/87 | 50.6% | 41/89 | 46.1% | 41.7% (12) | 54.5% (11) |
| Lucknow Super Giants | 11/27 | 40.7% | 14/27 | 51.9% | 9/17 | 52.9% | 28.6% (14) | 46.2% (13) |
| Mumbai Indians | 57/95 | 60.0% | 48/95 | 50.5% | 52/101 | 51.5% | 50.0% (14) | 41.7% (12) |
| Pune Warriors | 4/16 | 25.0% | 5/19 | 26.3% | 3/10 | 30.0% | - (0) | - (0) |
| Punjab Kings | 43/92 | 46.7% | 45/95 | 47.4% | 41/88 | 46.6% | 46.2% (13) | 75.0% (12) |
| Rajasthan Royals | 44/74 | 59.5% | 33/78 | 42.3% | 48/97 | 49.5% | 42.9% (14) | 38.5% (13) |
| Rising Pune Supergiant | 5/11 | 45.5% | 8/14 | 57.1% | 2/5 | 40.0% | - (0) | - (0) |
| Royal Challengers Bengaluru | 50/97 | 51.5% | 47/98 | 48.0% | 48/88 | 54.5% | 60.0% (10) | 75.0% (16) |
| Sunrisers Hyderabad | 43/69 | 62.3% | 29/67 | 43.3% | 31/74 | 41.9% | 58.3% (12) | 50.0% (12) |

| Team | Home chase | Home defend | Bahar chase | Bahar defend | Home sabse bada chase | Bahar sabse bada chase | Home sabse chhota defend | Bahar sabse chhota defend |
|---|---|---|---|---|---|---|---|---|
| Chennai Super Kings | 22/32 (68.8%) | 33/51 (64.7%) | 50/85 (58.8%) | 39/89 (43.8%) | 205 | 205 | 134 | 116 |
| Deccan Chargers | 1/6 (16.7%) | 2/12 (16.7%) | 10/26 (38.5%) | 16/31 (51.6%) | 126 | 184 | 132 | 129 |
| Delhi Capitals | 16/37 (43.2%) | 21/51 (41.2%) | 59/115 (51.3%) | 26/62 (41.9%) | 208 | 225 | 152 | 130 |
| Gujarat Lions | 5/8 (62.5%) | 0/5 (0.0%) | 7/8 (87.5%) | 1/8 (12.5%) | 180 | 195 | - | 172 |
| Gujarat Titans | 6/12 (50.0%) | 11/17 (64.7%) | 21/30 (70.0%) | 8/16 (50.0%) | 203 | 214 | 168 | 135 |
| Kochi Tuskers Kerala | 0/2 (0.0%) | 1/2 (50.0%) | 3/4 (75.0%) | 1/5 (20.0%) | - | 182 | 156 | 132 |
| Kolkata Knight Riders | 28/43 (65.1%) | 25/50 (50.0%) | 52/92 (56.5%) | 29/72 (40.3%) | 183 | 205 | 131 | 136 |
| Lucknow Super Giants | 5/9 (55.6%) | 5/16 (31.2%) | 8/21 (38.1%) | 15/23 (65.2%) | 187 | 212 | 163 | 153 |
| Mumbai Indians | 30/49 (61.2%) | 26/44 (59.1%) | 47/87 (54.0%) | 51/103 (49.5%) | 228 | 218 | 139 | 120 |
| Pune Warriors | 2/10 (20.0%) | 2/6 (33.3%) | 4/15 (26.7%) | 4/14 (28.6%) | 155 | 148 | 166 | 129 |
| Punjab Kings | 20/40 (50.0%) | 21/50 (42.0%) | 47/85 (55.3%) | 33/87 (37.9%) | 219 | 264 | 111 | 119 |
| Rajasthan Royals | 28/40 (70.0%) | 14/32 (43.8%) | 45/90 (50.0%) | 34/80 (42.5%) | 220 | 223 | 144 | 144 |
| Rising Pune Supergiant | 4/6 (66.7%) | 1/5 (20.0%) | 4/7 (57.1%) | 4/9 (44.4%) | 184 | 172 | 157 | 148 |
| Royal Challengers Bengaluru | 22/40 (55.0%) | 23/50 (46.0%) | 52/93 (55.9%) | 41/87 (47.1%) | 205 | 227 | 156 | 126 |
| Sunrisers Hyderabad | 21/31 (67.7%) | 21/35 (60.0%) | 27/62 (43.5%) | 31/73 (42.5%) | 245 | 243 | 126 | 118 |

**Home Rule:**
- **IPL mein ghar ka faayda ab nahi hai.** Sab season mein home team 52.7% jeeti, **2025 se sirf 44%**, 2026 mein 48%. Model mein bhi home ka asar zero nikla. **Sirf ghar ki wajah se kisi team par bet mat chuno.**
- **CSK ghar par purane daur mein 65.5% jeeti, lekin 2025 se sirf 38.5%.**
- **DC ghar par 2025 se sirf 25% (12 match), bahar 67%.** LSG ghar par 2025 se 29%.
- **PBKS bahar 2025 se 75% (12 match).** RCB bahar 75% (16 match).
- SRH ghar par 62% (purana record), 2025 se 58%.

| 1st inn score | n | Chase% sab | Home team chase kare (n) | Away team chase kare (n) |
|---|---|---|---|---|
| 140 tak | 208 | 82.2% | 77.8% (72) | 82.4% (51) |
| 141-155 | 172 | 75.0% | 72.5% (51) | 80.8% (52) |
| 156-170 | 238 | 56.3% | 67.7% (62) | 52.2% (92) |
| 171-185 | 212 | 50.9% | 59.2% (76) | 49.4% (77) |
| 186-200 | 153 | 37.9% | 38.2% (34) | 42.9% (70) |
| 201-220 | 125 | 28.0% | 33.3% (45) | 26.1% (46) |
| 221+ | 77 | 14.3% | 8.0% (25) | 21.1% (38) |

---
## 5. Grounds: kahan high score chase hota hai, kahan low score defend hota hai

| Ground | n | Avg 1st inn | Chase% | n 2025+ | Avg 2025+ | Chase% 2025+ | n 2026+ | Avg 2026+ | Chase% 2026+ |
|---|---|---|---|---|---|---|---|---|---|
| Wankhede (Mumbai) | 130 | 173 | 54.6% | 13 | 201 | 53.8% | 7 | 220 | 57.1% |
| Eden Gardens (Kolkata) | 98 | 172 | 56.1% | 12 | 196 | 41.7% | 6 | 193 | 50.0% |
| Arun Jaitley / Kotla (Delhi) | 98 | 173 | 53.1% | 13 | 187 | 69.2% | 7 | 172 | 85.7% |
| Chepauk (Chennai) | 96 | 166 | 46.9% | 13 | 176 | 69.2% | 7 | 188 | 71.4% |
| Chinnaswamy (Bengaluru) | 93 | 179 | 54.8% | 9 | 192 | 66.7% | 5 | 195 | 80.0% |
| Uppal (Hyderabad) | 86 | 170 | 53.5% | 12 | 207 | 50.0% | 7 | 209 | 28.6% |
| Sawai Mansingh (Jaipur) | 67 | 169 | 65.7% | 11 | 208 | 63.6% | 4 | 226 | 75.0% |
| PCA Mohali | 59 | 169 | 57.6% | 0 | - | - | 0 | - | - |
| Narendra Modi / Motera (Ahmedabad) | 51 | 180 | 49.0% | 17 | 200 | 35.3% | 8 | 182 | 50.0% |
| MCA / Sahara (Pune) | 51 | 162 | 45.1% | 0 | - | - | 0 | - | - |
| Dubai International Stadium | 43 | 163 | 51.2% | 0 | - | - | 0 | - | - |
| DY Patil (Navi Mumbai) | 37 | 160 | 54.1% | 0 | - | - | 0 | - | - |
| Sheikh Zayed (Abu Dhabi) | 35 | 159 | 60.0% | 0 | - | - | 0 | - | - |
| Sharjah Cricket Stadium | 28 | 159 | 64.3% | 0 | - | - | 0 | - | - |
| Brabourne (Mumbai) | 27 | 179 | 48.1% | 0 | - | - | 0 | - | - |
| Ekana (Lucknow) | 26 | 176 | 61.5% | 13 | 184 | 76.9% | 5 | 169 | 80.0% |
| Dharamsala | 18 | 195 | 38.9% | 5 | 224 | 40.0% | 4 | 222 | 50.0% |
| Mullanpur (New Chandigarh) | 17 | 187 | 52.9% | 12 | 195 | 50.0% | 6 | 219 | 66.7% |
| Visakhapatnam | 15 | 172 | 53.3% | 2 | 186 | 100.0% | 0 | - | - |
| Kingsmead | 14 | 152 | 42.9% | 0 | - | - | 0 | - | - |
| SuperSport Park | 11 | 152 | 72.7% | 0 | - | - | 0 | - | - |
| Holkar (Indore) | 9 | 160 | 88.9% | 0 | - | - | 0 | - | - |
| Rajkot | 9 | 171 | 66.7% | 0 | - | - | 0 | - | - |
| Raipur | 8 | 154 | 75.0% | 2 | 179 | 100.0% | 2 | 179 | 100.0% |
| New Wanderers Stadium | 8 | 144 | 62.5% | 0 | - | - | 0 | - | - |
| Barsapara (Guwahati) | 7 | 172 | 57.1% | 4 | 165 | 75.0% | 2 | 164 | 100.0% |
| Cuttack | 7 | 168 | 42.9% | 0 | - | - | 0 | - | - |
| St George's Park | 7 | 159 | 57.1% | 0 | - | - | 0 | - | - |
| Ranchi | 6 | 149 | 83.3% | 0 | - | - | 0 | - | - |
| Newlands | 5 | 144 | 20.0% | 0 | - | - | 0 | - | - |
| Kanpur | 4 | 161 | 100.0% | 0 | - | - | 0 | - | - |
| Kochi | 4 | 151 | 25.0% | 0 | - | - | 0 | - | - |
| Nagpur | 3 | 149 | 33.3% | 0 | - | - | 0 | - | - |
| De Beers Diamond Oval | 3 | 158 | 66.7% | 0 | - | - | 0 | - | - |
| Buffalo Park | 3 | 147 | 33.3% | 0 | - | - | 0 | - | - |
| OUTsurance Oval | 2 | 135 | 50.0% | 0 | - | - | 0 | - | - |

| Ground | n | Median 1st inn | Sabse bada chase | 180+ chase hua | Sabse chhota defend | 140 ya kam defend hua | Toss winner jeeta | Toss jeet kar field | 180+ banne ka % |
|---|---|---|---|---|---|---|---|---|---|
| Wankhede (Mumbai) | 130 | 174 | 243 | 19/56 (33.9%) | 118 | 5/22 (22.7%) | 51.5% | 76.9% | 43.1% |
| Eden Gardens (Kolkata) | 98 | 172 | 261 | 10/35 (28.6%) | 131 | 4/17 (23.5%) | 51.0% | 70.4% | 35.7% |
| Arun Jaitley / Kotla (Delhi) | 98 | 171 | 264 | 13/42 (31.0%) | 143 | 0/16 (0.0%) | 52.0% | 62.2% | 42.9% |
| Chepauk (Chennai) | 96 | 163 | 210 | 10/33 (30.3%) | 126 | 2/18 (11.1%) | 51.0% | 47.9% | 34.4% |
| Chinnaswamy (Bengaluru) | 93 | 178 | 212 | 16/46 (34.8%) | 138 | 1/10 (10.0%) | 53.8% | 90.3% | 49.5% |
| Uppal (Hyderabad) | 86 | 165 | 245 | 9/31 (29.0%) | 126 | 6/19 (31.6%) | 37.2% | 58.1% | 36.0% |
| Sawai Mansingh (Jaipur) | 67 | 167 | 228 | 11/24 (45.8%) | 144 | 0/9 (0.0%) | 56.7% | 58.2% | 35.8% |
| PCA Mohali | 59 | 173 | 214 | 8/21 (38.1%) | 150 | 0/8 (0.0%) | 49.2% | 71.2% | 35.6% |
| Narendra Modi / Motera (Ahmedabad) | 51 | 177 | 204 | 6/22 (27.3%) | 130 | 2/6 (33.3%) | 45.1% | 72.5% | 43.1% |
| MCA / Sahara (Pune) | 51 | 164 | 195 | 3/12 (25.0%) | 119 | 3/8 (37.5%) | 54.9% | 62.7% | 23.5% |
| Dubai International Stadium | 43 | 164 | 178 | 0/9 (0.0%) | 126 | 2/9 (22.2%) | 41.9% | 58.1% | 20.9% |
| DY Patil (Navi Mumbai) | 37 | 160 | 205 | 2/9 (22.2%) | 142 | 0/6 (0.0%) | 54.1% | 73.0% | 24.3% |
| Sheikh Zayed (Abu Dhabi) | 35 | 162 | 205 | 4/10 (40.0%) | 132 | 1/8 (12.5%) | 51.4% | 51.4% | 28.6% |
| Sharjah Cricket Stadium | 28 | 149 | 223 | 2/8 (25.0%) | 125 | 1/10 (10.0%) | 57.1% | 71.4% | 28.6% |
| Brabourne (Mumbai) | 27 | 180 | 210 | 3/14 (21.4%) | 177 | 0/2 (0.0%) | 51.9% | 66.7% | 51.9% |
| Ekana (Lucknow) | 26 | 173 | 227 | 6/11 (54.5%) | 126 | 2/3 (66.7%) | 69.2% | 76.9% | 42.3% |
| Dharamsala | 18 | 195 | 210 | 4/12 (33.3%) | 167 | 0/1 (0.0%) | 44.4% | 94.4% | 66.7% |
| Mullanpur (New Chandigarh) | 17 | 192 | 222 | 3/10 (30.0%) | 111 | 1/2 (50.0%) | 58.8% | 70.6% | 58.8% |
| Visakhapatnam | 15 | 167 | 209 | 1/5 (20.0%) | 137 | 1/4 (25.0%) | 53.3% | 46.7% | 33.3% |
| Kingsmead | 14 | 149 | 168 | 0/2 (0.0%) | 116 | 2/5 (40.0%) | 57.1% | 28.6% | 14.3% |
| SuperSport Park | 11 | 153 | 188 | 1/1 (100.0%) | 145 | 0/2 (0.0%) | 63.6% | 54.5% | 9.1% |
| Holkar (Indore) | 9 | 163 | 198 | 1/2 (50.0%) | 245 | 0/2 (0.0%) | 77.8% | 88.9% | 22.2% |
| Rajkot | 9 | 171 | 183 | 2/4 (50.0%) | 154 | 0/1 (0.0%) | 44.4% | 77.8% | 44.4% |
| Raipur | 8 | 160 | 192 | 1/1 (100.0%) | 163 | 0/3 (0.0%) | 62.5% | 62.5% | 12.5% |
| New Wanderers Stadium | 8 | 144 | 160 | 0/0 (-) | 134 | 1/3 (33.3%) | 37.5% | 75.0% | 0.0% |
| Barsapara (Guwahati) | 7 | 182 | 201 | 1/4 (25.0%) | 182 | 0/1 (0.0%) | 42.9% | 85.7% | 57.1% |
| Cuttack | 7 | 170 | 149 | 0/2 (0.0%) | 170 | 0/1 (0.0%) | 71.4% | 71.4% | 28.6% |
| St George's Park | 7 | 153 | 153 | 0/1 (0.0%) | 157 | 0/0 (-) | 42.9% | 0.0% | 14.3% |
| Ranchi | 6 | 143 | 185 | 1/1 (100.0%) | 170 | 0/3 (0.0%) | 50.0% | 66.7% | 16.7% |
| Newlands | 5 | 139 | 101 | 0/1 (0.0%) | 133 | 2/3 (66.7%) | 60.0% | 20.0% | 20.0% |
| Kanpur | 4 | 163 | 195 | 1/1 (100.0%) | - | 0/1 (0.0%) | 100.0% | 100.0% | 25.0% |
| Kochi | 4 | 156 | 161 | 0/0 (-) | 129 | 1/1 (100.0%) | 25.0% | 50.0% | 0.0% |
| Nagpur | 3 | 151 | 138 | 0/0 (-) | 151 | 0/1 (0.0%) | 33.3% | 33.3% | 0.0% |
| De Beers Diamond Oval | 3 | 166 | 168 | 0/0 (-) | 166 | 0/1 (0.0%) | 66.7% | 33.3% | 0.0% |
| Buffalo Park | 3 | 148 | 116 | 0/0 (-) | 148 | 0/1 (0.0%) | 66.7% | 0.0% | 0.0% |
| OUTsurance Oval | 2 | 135 | 120 | 0/0 (-) | 150 | 0/1 (0.0%) | 100.0% | 50.0% | 0.0% |

| Ground | 140 tak: chase | 141-160 | 161-180 | 181+ |
|---|---|---|---|---|
| Wankhede (Mumbai) | 17/22 (77.3%) | 14/18 (77.8%) | 21/35 (60.0%) | 19/55 (34.5%) |
| Eden Gardens (Kolkata) | 13/17 (76.5%) | 14/16 (87.5%) | 18/31 (58.1%) | 10/34 (29.4%) |
| Arun Jaitley / Kotla (Delhi) | 16/16 (100.0%) | 9/13 (69.2%) | 14/27 (51.9%) | 13/42 (31.0%) |
| Chepauk (Chennai) | 16/18 (88.9%) | 13/28 (46.4%) | 7/18 (38.9%) | 9/32 (28.1%) |
| Chinnaswamy (Bengaluru) | 9/10 (90.0%) | 14/18 (77.8%) | 12/19 (63.2%) | 16/46 (34.8%) |
| Uppal (Hyderabad) | 13/19 (68.4%) | 15/21 (71.4%) | 9/15 (60.0%) | 9/31 (29.0%) |
| Sawai Mansingh (Jaipur) | 9/9 (100.0%) | 15/19 (78.9%) | 9/16 (56.2%) | 11/23 (47.8%) |
| PCA Mohali | 8/8 (100.0%) | 9/12 (75.0%) | 9/18 (50.0%) | 8/21 (38.1%) |
| Narendra Modi / Motera (Ahmedabad) | 4/6 (66.7%) | 8/8 (100.0%) | 8/16 (50.0%) | 5/21 (23.8%) |
| MCA / Sahara (Pune) | 5/8 (62.5%) | 8/13 (61.5%) | 7/19 (36.8%) | 3/11 (27.3%) |
| Dubai International Stadium | 7/9 (77.8%) | 6/7 (85.7%) | 9/18 (50.0%) | 0/9 (0.0%) |
| DY Patil (Navi Mumbai) | 6/6 (100.0%) | 10/14 (71.4%) | 2/8 (25.0%) | 2/9 (22.2%) |
| Sheikh Zayed (Abu Dhabi) | 7/8 (87.5%) | 6/8 (75.0%) | 4/9 (44.4%) | 4/10 (40.0%) |
| Sharjah Cricket Stadium | 9/10 (90.0%) | 5/6 (83.3%) | 2/4 (50.0%) | 2/8 (25.0%) |
| Brabourne (Mumbai) | 2/2 (100.0%) | 3/3 (100.0%) | 6/10 (60.0%) | 2/12 (16.7%) |
| Ekana (Lucknow) | 1/3 (33.3%) | 4/5 (80.0%) | 6/8 (75.0%) | 5/10 (50.0%) |
| Dharamsala | 1/1 (100.0%) | 1/1 (100.0%) | 1/4 (25.0%) | 4/12 (33.3%) |
| Mullanpur (New Chandigarh) | 1/2 (50.0%) | 3/3 (100.0%) | 2/2 (100.0%) | 3/10 (30.0%) |
| Visakhapatnam | 3/4 (75.0%) | 1/1 (100.0%) | 3/5 (60.0%) | 1/5 (20.0%) |
| Kingsmead | 3/5 (60.0%) | 1/3 (33.3%) | 2/4 (50.0%) | 0/2 (0.0%) |
| SuperSport Park | 2/2 (100.0%) | 3/4 (75.0%) | 2/4 (50.0%) | 1/1 (100.0%) |
| Holkar (Indore) | 2/2 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) |
| Rajkot | 1/1 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | 1/3 (33.3%) |
| Raipur | 3/3 (100.0%) | 1/1 (100.0%) | 1/3 (33.3%) | 1/1 (100.0%) |
| New Wanderers Stadium | 2/3 (66.7%) | 3/4 (75.0%) | 0/1 (0.0%) | - |
| Barsapara (Guwahati) | 1/1 (100.0%) | 2/2 (100.0%) | - | 1/4 (25.0%) |
| Cuttack | 1/1 (100.0%) | 2/2 (100.0%) | 0/2 (0.0%) | 0/2 (0.0%) |
| St George's Park | - | 4/5 (80.0%) | 0/1 (0.0%) | 0/1 (0.0%) |
| Ranchi | 3/3 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 1/1 (100.0%) |
| Newlands | 1/3 (33.3%) | - | 0/1 (0.0%) | 0/1 (0.0%) |
| Kanpur | 1/1 (100.0%) | 1/1 (100.0%) | 1/1 (100.0%) | 1/1 (100.0%) |
| Kochi | 0/1 (0.0%) | 0/2 (0.0%) | 1/1 (100.0%) | - |
| Nagpur | 1/1 (100.0%) | 0/2 (0.0%) | - | - |
| De Beers Diamond Oval | 1/1 (100.0%) | - | 1/2 (50.0%) | - |
| Buffalo Park | 1/1 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | - |
| OUTsurance Oval | 1/1 (100.0%) | 0/1 (0.0%) | - | - |

**Ground Rules (2025 se ke data par):**
- **Delhi Kotla Rule:** 2025 se chase 69%, 2026 mein 7 mein se 6 chase. Kotla mein 140 ya kam score kabhi defend nahi hua (0/16). **Kotla mein chase side par bet.**
- **Chepauk Rule:** purane daur mein Chepauk defend ka ground tha (chase 47%), lekin **2025 se chase 69%.** Ab chase side par jhuko.
- **Chinnaswamy Rule:** 2026 mein chase 80%. Toss jeet kar 90% field lete hain. Chase side par bet. Lekin yahan 30% match jackpot hote hain, stake chhoti.
- **Ekana Rule:** 2025 se chase 77%. Chase side par bet.
- **Uppal Rule:** 2026 mein average 209 aur chase sirf 29% (7 match). **Uppal mein 200+ = defend side par bet.**
- **Ahmedabad Rule:** 2025 se chase sirf 35% (17 match), average 200. **Ahmedabad mein defend side par bet.**
- **Jaipur:** 2025 se chase 64%, 2026 average 226. Bade score bhi chase hote hain.
- **Wankhede:** 2026 average 220, chase 57%. Coin-flip, calculator se faisla.
- **Dharamsala aur Mullanpur:** 2026 mein average 219-222. Bada score normal hai, 220 tak target dekh kar calculator se faisla.

---
## 6. Teams

| Team (city) | Match | Jeete | Haare | Win% sab | Win% 2025+ (match) | Win% 2026+ (match) | Pehle batting win% | Chase win% | Title |
|---|---|---|---|---|---|---|---|---|---|
| Gujarat Titans | 77 | 47 | 30 | 61.0% | 59.4% (32) | 58.8% (17) | 57.6% | 64.3% | 1 |
| Chennai Super Kings | 265 | 148 | 117 | 55.8% | 35.7% (28) | 42.9% (14) | 51.4% | 61.5% | 5 |
| Mumbai Indians | 291 | 157 | 134 | 54.0% | 43.3% (30) | 28.6% (14) | 52.4% | 56.6% | 5 |
| Kolkata Knight Riders | 276 | 142 | 134 | 51.4% | 44.0% (25) | 46.2% (13) | 44.3% | 59.3% | 3 |
| Royal Challengers Bengaluru | 283 | 145 | 138 | 51.2% | 71.0% (31) | 68.8% (16) | 46.7% | 55.6% | 2 |
| Rajasthan Royals | 249 | 125 | 124 | 50.2% | 43.3% (30) | 56.2% (16) | 42.9% | 56.2% | 1 |
| Rising Pune Supergiant | 30 | 15 | 15 | 50.0% | - (0) | - (0) | 35.7% | 61.5% | 0 |
| Sunrisers Hyderabad | 210 | 103 | 107 | 49.0% | 53.6% (28) | 60.0% (15) | 48.1% | 51.6% | 1 |
| Lucknow Super Giants | 71 | 34 | 37 | 47.9% | 35.7% (28) | 28.6% (14) | 51.3% | 43.3% | 0 |
| Punjab Kings | 275 | 129 | 146 | 46.9% | 58.6% (29) | 53.8% (13) | 39.4% | 53.6% | 0 |
| Delhi Capitals | 277 | 129 | 148 | 46.6% | 51.9% (27) | 50.0% (14) | 41.6% | 49.3% | 0 |
| Gujarat Lions | 30 | 13 | 17 | 43.3% | - (0) | - (0) | 7.7% | 75.0% | 0 |
| Kochi Tuskers Kerala | 14 | 6 | 8 | 42.9% | - (0) | - (0) | 28.6% | 50.0% | 0 |
| Deccan Chargers | 75 | 29 | 46 | 38.7% | - (0) | - (0) | 41.9% | 34.4% | 1 |
| Pune Warriors | 45 | 12 | 33 | 26.7% | - (0) | - (0) | 30.0% | 24.0% | 0 |

| Team | Defend: jeet/match | Defend% | Chase: jeet/match | Chase% |
|---|---|---|---|---|
| Chennai Super Kings | 3/8 | 37.5% | 3/6 | 50.0% |
| Delhi Capitals | 1/5 | 20.0% | 6/9 | 66.7% |
| Gujarat Titans | 4/7 | 57.1% | 6/10 | 60.0% |
| Kolkata Knight Riders | 1/5 | 20.0% | 4/7 | 57.1% |
| Lucknow Super Giants | 0/7 | 0.0% | 3/5 | 60.0% |
| Mumbai Indians | 1/7 | 14.3% | 3/6 | 50.0% |
| Punjab Kings | 1/5 | 20.0% | 6/8 | 75.0% |
| Rajasthan Royals | 4/9 | 44.4% | 4/6 | 66.7% |
| Royal Challengers Bengaluru | 4/7 | 57.1% | 7/8 | 87.5% |
| Sunrisers Hyderabad | 6/10 | 60.0% | 3/5 | 60.0% |

**Team Rules:**
- **RCB Rule:** RCB 2025 aur 2026 dono season champion. **2025 se 71% jeeti, 2026 mein chase 8 mein se 7.** RCB chase kare to RCB par bet.
- **GT 2025 se 59%, PBKS 59%, SRH 54%.**
- **CSK aur LSG 2025 se sirf 36%, MI 43% (2026 mein 29%).** In teams ke favourite hone par stake chhoti.
- **LSG Defend Rule:** LSG 2026 mein pehle bat kar 7 mein se 0 jeeti. **LSG pehle bat kare to dusri team par bet.**
- **MI Defend Rule:** MI 2026 mein defend 7 mein se 1. MI pehle bat kare to dusri team par bet.
- **SRH 2026 mein defend 10 mein se 6** (60%), baaki teams se behtar.
- **DC 2026 mein chase 9 mein se 6, defend 5 mein se 1.**

---
## 7. Head to head

| Team A | Team B | Match | A-B | 2025+ (A-B) | Aakhri 5 (purana se naya) | Is jodi mein chase% |
|---|---|---|---|---|---|---|
| Kolkata Knight Riders | Mumbai Indians | 37 | 12-25 | 1-2 | A A B B A | 58.3% |
| Chennai Super Kings | Kolkata Knight Riders | 32 | 21-11 | 2-1 | B A B A A | 69.0% |
| Kolkata Knight Riders | Sunrisers Hyderabad | 32 | 21-11 | 2-2 | A A B B A | 48.3% |
| Punjab Kings | Sunrisers Hyderabad | 26 | 8-18 | 1-2 | B B B A B | 46.2% |
| Chennai Super Kings | Delhi Capitals | 33 | 21-12 | 2-1 | A B B A A | 45.5% |
| Delhi Capitals | Royal Challengers Bengaluru | 34 | 13-21 | 2-2 | B A B A B | 54.5% |
| Kolkata Knight Riders | Punjab Kings | 34 | 21-13 | 0-1 | A B A B B | 61.3% |
| Chennai Super Kings | Royal Challengers Bengaluru | 35 | 21-14 | 0-3 | A B B B B | 47.1% |
| Chennai Super Kings | Sunrisers Hyderabad | 24 | 15-9 | 0-3 | B A B B B | 62.5% |
| Deccan Chargers | Kolkata Knight Riders | 9 | 2-7 | 0-0 | B B B B B | 44.4% |
| Deccan Chargers | Rajasthan Royals | 9 | 2-7 | 0-0 | B B B B A | 77.8% |
| Gujarat Lions | Sunrisers Hyderabad | 5 | 0-5 | 0-0 | B B B B B | 100.0% |
| Gujarat Titans | Rajasthan Royals | 11 | 8-3 | 3-2 | A B B A A | 63.6% |
| Gujarat Titans | Sunrisers Hyderabad | 7 | 6-1 | 3-0 | A A A A A | 57.1% |
| Pune Warriors | Royal Challengers Bengaluru | 5 | 0-5 | 0-0 | B B B B B | 20.0% |
| Punjab Kings | Rajasthan Royals | 31 | 13-18 | 1-2 | B A B A B | 43.3% |
| Deccan Chargers | Punjab Kings | 10 | 3-7 | 0-0 | A B A B B | 60.0% |
| Delhi Capitals | Kolkata Knight Riders | 36 | 16-20 | 1-2 | B B B B A | 55.9% |
| Delhi Capitals | Mumbai Indians | 38 | 17-21 | 1-2 | B A B B A | 47.4% |
| Kolkata Knight Riders | Royal Challengers Bengaluru | 36 | 20-16 | 0-2 | A A A B B | 63.6% |
| Lucknow Super Giants | Rajasthan Royals | 8 | 2-6 | 1-2 | B B A B B | 25.0% |
| Mumbai Indians | Pune Warriors | 6 | 5-1 | 0-0 | A B A A A | 33.3% |
| Mumbai Indians | Sunrisers Hyderabad | 26 | 15-11 | 2-1 | B A A A B | 56.0% |
| Rajasthan Royals | Sunrisers Hyderabad | 24 | 10-14 | 1-3 | B B B B A | 50.0% |
| Deccan Chargers | Delhi Capitals | 11 | 4-7 | 0-0 | A A B B B | 54.5% |
| Kolkata Knight Riders | Pune Warriors | 5 | 4-1 | 0-0 | A A A A B | 20.0% |
| Kolkata Knight Riders | Rajasthan Royals | 31 | 17-14 | 3-0 | B B A A A | 58.6% |
| Lucknow Super Giants | Mumbai Indians | 9 | 6-3 | 1-2 | A A A B B | 22.2% |
| Lucknow Super Giants | Sunrisers Hyderabad | 7 | 5-2 | 2-1 | A B A B A | 85.7% |
| Pune Warriors | Rajasthan Royals | 5 | 1-4 | 0-0 | B B B A B | 80.0% |
| Royal Challengers Bengaluru | Sunrisers Hyderabad | 27 | 12-15 | 1-2 | B A B A B | 40.0% |
| Chennai Super Kings | Deccan Chargers | 10 | 6-4 | 0-0 | B A A A A | 40.0% |
| Chennai Super Kings | Gujarat Titans | 10 | 4-6 | 1-2 | A B A B B | 44.4% |
| Chennai Super Kings | Pune Warriors | 6 | 4-2 | 0-0 | A B A B A | 33.3% |
| Deccan Chargers | Mumbai Indians | 10 | 4-6 | 0-0 | B B A B B | 30.0% |
| Deccan Chargers | Pune Warriors | 4 | 3-1 | 0-0 | B A A A | 50.0% |
| Delhi Capitals | Gujarat Lions | 4 | 3-1 | 0-0 | B A A A | 75.0% |
| Delhi Capitals | Gujarat Titans | 8 | 3-5 | 0-3 | A A B B B | 50.0% |
| Delhi Capitals | Lucknow Super Giants | 8 | 5-3 | 3-0 | A A A A A | 62.5% |
| Delhi Capitals | Rajasthan Royals | 32 | 17-15 | 3-0 | B A A A A | 51.7% |
| Delhi Capitals | Sunrisers Hyderabad | 26 | 12-14 | 1-1 | A B B A B | 45.8% |
| Gujarat Lions | Kolkata Knight Riders | 4 | 3-1 | 0-0 | A A B A | 100.0% |
| Gujarat Lions | Rising Pune Supergiant | 4 | 3-1 | 0-0 | A A A B | 100.0% |
| Gujarat Titans | Kolkata Knight Riders | 6 | 4-2 | 2-1 | B A A A B | 50.0% |
| Gujarat Titans | Lucknow Super Giants | 8 | 5-3 | 1-2 | A B B B A | 37.5% |
| Gujarat Titans | Royal Challengers Bengaluru | 10 | 4-6 | 2-3 | A B A B B | 90.0% |
| Kolkata Knight Riders | Lucknow Super Giants | 8 | 3-5 | 1-2 | A A B B A | 28.6% |
| Kolkata Knight Riders | Rising Pune Supergiant | 4 | 3-1 | 0-0 | A A A B | 100.0% |
| Lucknow Super Giants | Punjab Kings | 8 | 3-5 | 0-4 | A B B B B | 37.5% |
| Lucknow Super Giants | Royal Challengers Bengaluru | 8 | 3-5 | 1-2 | B A B B A | 42.9% |
| Mumbai Indians | Rising Pune Supergiant | 6 | 2-4 | 0-0 | A B B B A | 50.0% |
| Mumbai Indians | Royal Challengers Bengaluru | 36 | 19-17 | 0-3 | A A B B B | 55.9% |
| Punjab Kings | Royal Challengers Bengaluru | 38 | 18-20 | 1-4 | A B B B B | 54.3% |
| Rajasthan Royals | Royal Challengers Bengaluru | 32 | 15-17 | 1-2 | A A B B A | 65.6% |
| Rising Pune Supergiant | Sunrisers Hyderabad | 4 | 3-1 | 0-0 | A B A A | 33.3% |
| Chennai Super Kings | Lucknow Super Giants | 7 | 3-4 | 2-1 | B B A A B | 85.7% |
| Chennai Super Kings | Mumbai Indians | 41 | 20-21 | 3-1 | A A B A A | 56.1% |
| Chennai Super Kings | Punjab Kings | 33 | 16-17 | 0-3 | B A B B B | 54.8% |
| Deccan Chargers | Royal Challengers Bengaluru | 11 | 6-5 | 0-0 | A B A B A | 36.4% |
| Delhi Capitals | Pune Warriors | 5 | 3-2 | 0-0 | A B A A B | 40.0% |
| Gujarat Lions | Royal Challengers Bengaluru | 5 | 2-3 | 0-0 | A B B B A | 60.0% |
| Gujarat Titans | Mumbai Indians | 9 | 5-4 | 2-2 | A A A B B | 0.0% |
| Chennai Super Kings | Rajasthan Royals | 32 | 16-16 | 0-3 | B A B B B | 56.2% |
| Delhi Capitals | Punjab Kings | 36 | 18-18 | 2-1 | A B A B A | 69.7% |
| Delhi Capitals | Rising Pune Supergiant | 4 | 2-2 | 0-0 | B B A A | 33.3% |
| Gujarat Lions | Mumbai Indians | 4 | 2-2 | 0-0 | A A B B | 100.0% |
| Gujarat Lions | Punjab Kings | 4 | 2-2 | 0-0 | A B B A | 50.0% |
| Gujarat Titans | Punjab Kings | 8 | 4-4 | 1-2 | B A B B A | 87.5% |
| Mumbai Indians | Punjab Kings | 36 | 18-18 | 1-3 | A B B B A | 54.3% |
| Mumbai Indians | Rajasthan Royals | 32 | 16-16 | 1-2 | B B A B B | 61.3% |
| Pune Warriors | Punjab Kings | 6 | 3-3 | 0-0 | A A B B B | 83.3% |
| Punjab Kings | Rising Pune Supergiant | 4 | 2-2 | 0-0 | A B A B | 100.0% |
| Rising Pune Supergiant | Royal Challengers Bengaluru | 4 | 2-2 | 0-0 | B B A A | 25.0% |

**Head-to-Head Rule (abhi ki teams, sabse kaam ke):**
- **MI v KKR: 25-12 MI.**
- **CSK v KKR: 21-11 CSK.** CSK v DC: 21-12 CSK.
- **SRH v PBKS: 18-8 SRH.**
- **GT v SRH: 6-1 GT, aakhri 5 sab GT.** GT par bet.
- **DC v LSG: aakhri 5 sab DC** (2025 se 3-0).
- **PBKS v LSG: 2025 se 4-0 PBKS.**
- **2025 se RCB ne CSK ko 3-0, PBKS ko 4-1, MI ko 3-0 haraya.** RCB par bet.
- **2025 se PBKS ne CSK ko 3-0, RR ne CSK ko 3-0, KKR ne RR ko 3-0 haraya.**

---
## 8. Favourite (form) kitni baar jeetta hai
Form favourite = season mein us waqt tak jis team ka win% 15+ point zyada tha.

| Haalat | Match | Favourite jeeta | Haara | Win% |
|---|---|---|---|---|
| Sab | 558 | 302 | 256 | 54.1% |
| 2025 se | 68 | 38 | 30 | 55.9% |
| Form ka farq 15-30 point | 278 | 159 | 119 | 57.2% |
| Form ka farq 30+ point | 280 | 143 | 137 | 51.1% |
| Favourite chase kare | 263 | 156 | 107 | 59.3% |
| Favourite pehle bat kare | 295 | 146 | 149 | 49.5% |
| Favourite home par | 184 | 106 | 78 | 57.6% |
| Favourite doosre ke ghar | 206 | 110 | 96 | 53.4% |
| Playoff/Final | 7 | 5 | 2 | 71.4% |

| Team | Favourite bani: jeet/match | Underdog bani: jeet/match |
|---|---|---|
| Chennai Super Kings | 40/77 (51.9%) | 22/42 (52.4%) |
| Deccan Chargers | 4/9 (44.4%) | 10/30 (33.3%) |
| Delhi Capitals | 33/61 (54.1%) | 28/70 (40.0%) |
| Gujarat Lions | 2/5 (40.0%) | 2/6 (33.3%) |
| Gujarat Titans | 14/29 (48.3%) | 6/8 (75.0%) |
| Kochi Tuskers Kerala | 0/2 (0.0%) | 3/4 (75.0%) |
| Kolkata Knight Riders | 34/61 (55.7%) | 28/62 (45.2%) |
| Lucknow Super Giants | 9/14 (64.3%) | 6/16 (37.5%) |
| Mumbai Indians | 39/64 (60.9%) | 35/66 (53.0%) |
| Pune Warriors | 1/5 (20.0%) | 4/21 (19.0%) |
| Punjab Kings | 34/61 (55.7%) | 38/68 (55.9%) |
| Rajasthan Royals | 32/64 (50.0%) | 17/46 (37.0%) |
| Rising Pune Supergiant | 2/3 (66.7%) | 5/10 (50.0%) |
| Royal Challengers Bengaluru | 33/60 (55.0%) | 26/63 (41.3%) |
| Sunrisers Hyderabad | 25/43 (58.1%) | 26/46 (56.5%) |

**Sabak:**
- **IPL mein form favourite sirf 54% jeetta hai.** Form ka farq 30+ ho tab bhi 51%. Form par zyada bharosa mat karo.
- **Favourite chase kare to 59%, pehle bat kare to sirf 49.5%.** **Favourite Bat First Rule:** form favourite pehle bat kare to underdog chase side par chhoti bet.

---
## 9. Close finishes aur momentum
- Chase karke jeete 646 match mein se **287 aakhri over (19+) mein jeete** (44%). **Aakhri Over Rule:** 19 over tak chase zinda ho to chase side ko hara hua mat samjho.
- Defend karke jeete 539 match mein se 124 match 10 ya kam run se, aur 154 match 40+ run se.
- **Momentum ka asar nahi:** pichhla match jeeti team agla 48.8% jeeti, haari team 51.3%. Is akele ki bina par bet ka faisla mat karo.
- Barish: 1243 mein se 9 no result aur 23 DLS.

---
## 10. Powerplay aur 10 over

| Haalat | n | Chase jeeta % |
|---|---|---|
| Pehli innings 6 over: 0-1 wicket | 704 | 46.7% |
| Pehli innings 6 over: 2-3 wicket | 435 | 63.9% |
| Pehli innings 6 over: 4+ wicket | 46 | 84.8% |
| Pehli innings 6 over: 55+ run | 316 | 40.2% |
| Pehli innings 6 over: 40 se kam run | 312 | 66.3% |
| Chase 6 over: 0-1 wicket | 645 | 70.5% |
| Chase 6 over: 3+ wicket | 222 | 25.2% |
| Chase 10 over: 4+ wicket | 240 | 20.0% |

**Powerplay Rule:**
- **Chase mein 6 over par 3+ wicket = chase sirf 25% jeeta.** Defend side par bet.
- **Chase mein 10 over par 4+ wicket = chase sirf 20%.** Defend side par aadhi stake.
- **Pehli innings mein 6 over par 4+ wicket = chase 85% jeeta.** Chase side par bet.
- Pehli innings 6 over mein 55+ ho to chase 40%.

Pehli innings 10 over par score aur wicket se pehle batting wali team ki jeet %:

| 10 over par run | 0-2 wicket | 3-4 wicket | 5+ wicket |
|---|---|---|---|
| 60 se kam | 23.3% (43) | 23.2% (112) | 12.1% (33) |
| 60-69 | 54.7% (106) | 31.8% (88) | 0.0% (12) |
| 70-79 | 42.6% (169) | 36.7% (98) | 11.1% (9) |
| 80-89 | 55.5% (200) | 59.2% (49) | 30.0% (10) |
| 90+ | 66.0% (203) | 52.0% (50) | - |

---
## 11. Pehli innings ka projection (live)
2025 se ka median zyada hai (aakhri column). Calculator purane aur naye ka mix leta hai. **2026 ke match mein aakhri column dekho.**

| Over | Wicket gire | n | Avg score us waqt | Baaki overs mein median | Range (25-75%) | Median 2025+ |
|---|---|---|---|---|---|---|
| 6 | 0-1 | 715 | 52 | +127 | +111 se +144 | +146 |
| 6 | 2-3 | 447 | 43 | +114 | +99 se +133 | +130 |
| 6 | 4-5 | 48 | 36 | +85 | +67 se +112 | +86 |
| 10 | 0-1 | 370 | 86 | +101 | +86 se +115 | +116 |
| 10 | 2-3 | 621 | 76 | +92 | +80 se +105 | +101 |
| 10 | 4-5 | 198 | 67 | +77 | +61 se +94 | +86 |
| 10 | 6+ | 21 | 59 | +31 | +25 se +57 | - |
| 15 | 0-1 | 87 | 142 | +57 | +51 se +67 | +63 |
| 15 | 2-3 | 499 | 127 | +54 | +46 se +63 | +61 |
| 15 | 4-5 | 484 | 113 | +49 | +40 se +58 | +54 |
| 15 | 6+ | 135 | 96 | +34 | +20 se +45 | +38 |

---
## 12. Chase grid aur live model
Chase karne wali team ka jeetne ka % (RRR = required run rate). Yeh 2008-2026 sab ka mix hai.

### 6 over par
| RRR \ wicket | 0-1 | 2-3 | 4-5 | 6+ |
|---|---|---|---|---|
| 8 se kam | 87% (295) | 75% (128) | 40% (10) | - |
| 8-9.99 | 65% (239) | 37% (164) | 33% (18) | - |
| 10-11.99 | 45% (89) | 14% (145) | 6% (18) | - |
| 12-13.99 | 5% (21) | 3% (30) | 0% (10) | - |
| 14+ | - | 0% (11) | - | - |

### 10 over par
| RRR \ wicket | 0-1 | 2-3 | 4-5 | 6+ |
|---|---|---|---|---|
| 8 se kam | 93% (149) | 88% (200) | 64% (25) | - |
| 8-9.99 | 73% (125) | 60% (175) | 36% (47) | 12% (8) |
| 10-11.99 | 61% (38) | 29% (147) | 16% (64) | - |
| 12-13.99 | 40% (10) | 14% (70) | 7% (55) | 0% (5) |
| 14+ | - | 0% (18) | 0% (24) | 0% (7) |

### 15 over par
| RRR \ wicket | 0-1 | 2-3 | 4-5 | 6+ |
|---|---|---|---|---|
| 8 se kam | 100% (54) | 97% (189) | 93% (81) | 71% (7) |
| 8-9.99 | 89% (18) | 82% (92) | 58% (65) | 33% (15) |
| 10-11.99 | - | 62% (68) | 41% (71) | 19% (27) |
| 12-13.99 | - | 45% (44) | 23% (81) | 7% (28) |
| 14+ | - | 20% (30) | 3% (116) | 1% (120) |

**Live model:** IPL ka apna model hai (calculator mein). Isko IPL ke har ball par check kiya:

| Model ne kaha | Ball | Asal mein chase jeeta |
|---|---|---|
| 0-10% | 20666 | 2.7% |
| 10-20% | 10780 | 15.3% |
| 20-30% | 9688 | 28.6% |
| 30-40% | 8788 | 37.4% |
| 40-50% | 9193 | 44.7% |
| 50-60% | 10478 | 53.1% |
| 60-70% | 11535 | 63.1% |
| 70-80% | 13558 | 73.2% |
| 80-90% | 15836 | 84.4% |
| 90-100% | 21268 | 96.9% |

Model achhi tarah milta hai. 80-90% bataya to asal 84%, 90%+ bataya to 97%.

---
## 13. Jackpot
**Jackpot** = jeetne wali team ka chance kisi waqt 25% ya kam tak gira. **Bada jackpot** = 10% ya kam. **Double jackpot** = winner pehle 75%+ favourite tha, phir 25% ya kam par gira, phir jeeta.

- **1185 match mein se 299 jackpot (25.2%).** Yani **har 4 mein se 1 match palat jata hai.** 2026 mein 70 mein se 22 (31%). Bada jackpot 91, double jackpot 48.
- Jackpot jeetne walon mein 138 chase wale aur 161 defend wale.

| Season | Match | Jackpot |
|---|---|---|
| 2008 | 54 | 9 (17%) |
| 2009 | 53 | 18 (34%) |
| 2010 | 59 | 11 (19%) |
| 2011 | 69 | 13 (19%) |
| 2012 | 73 | 25 (34%) |
| 2013 | 73 | 19 (26%) |
| 2014 | 57 | 12 (21%) |
| 2015 | 52 | 15 (29%) |
| 2016 | 56 | 12 (21%) |
| 2017 | 57 | 18 (32%) |
| 2018 | 57 | 19 (33%) |
| 2019 | 57 | 15 (26%) |
| 2020 | 56 | 11 (20%) |
| 2021 | 59 | 15 (25%) |
| 2022 | 74 | 17 (23%) |
| 2023 | 71 | 18 (25%) |
| 2024 | 70 | 14 (20%) |
| 2025 | 68 | 16 (24%) |
| 2026 | 70 | 22 (31%) |

### Bade jackpot (sabse kam chance se jeete)
| Date | Ground | Match | Winner | Sabse kam chance | Kab |
|---|---|---|---|---|---|
| 2026-05-11 | Dharamsala | Punjab Kings 210 v Delhi Capitals 216 | **Delhi Capitals** | 4.9% | 4.3 ov, 178 chahiye 93 ball mein, 3 wkt |
| 2026-05-10 | Raipur | Mumbai Indians 166 v Royal Challengers Bengaluru 167 | **Royal Challengers Bengaluru** (double) | 1.6% | 19.3 ov, 10 chahiye 3 ball mein, 8 wkt |
| 2026-04-25 | Arun Jaitley / Kotla (Delhi) | Delhi Capitals 264 v Punjab Kings 265 | **Punjab Kings** | 4.6% | 0.5 ov, 256 chahiye 115 ball mein, 0 wkt |
| 2026-04-09 | Eden Gardens (Kolkata) | Kolkata Knight Riders 181 v Lucknow Super Giants 182 | **Lucknow Super Giants** | 2.3% | 19.4 ov, 7 chahiye 2 ball mein, 7 wkt |
| 2025-04-15 | Mullanpur (New Chandigarh) | Punjab Kings 111 v Kolkata Knight Riders 95 | **Punjab Kings** | 4.1% | 7.2 ov, 50 chahiye 76 ball mein, 2 wkt |
| 2025-03-24 | Visakhapatnam | Lucknow Super Giants 209 v Delhi Capitals 211 | **Delhi Capitals** | 2.7% | 7.0 ov, 144 chahiye 78 ball mein, 5 wkt |
| 2024-04-26 | Eden Gardens (Kolkata) | Kolkata Knight Riders 261 v Punjab Kings 262 | **Punjab Kings** | 4.4% | 1.2 ov, 253 chahiye 112 ball mein, 0 wkt |
| 2024-04-16 | Eden Gardens (Kolkata) | Kolkata Knight Riders 223 v Rajasthan Royals 224 | **Rajasthan Royals** | 1.4% | 14.1 ov, 96 chahiye 35 ball mein, 6 wkt |
| 2024-04-10 | Sawai Mansingh (Jaipur) | Rajasthan Royals 196 v Gujarat Titans 199 | **Gujarat Titans** | 4.6% | 18.1 ov, 34 chahiye 11 ball mein, 6 wkt |
| 2023-05-07 | Sawai Mansingh (Jaipur) | Rajasthan Royals 214 v Sunrisers Hyderabad 217 | **Sunrisers Hyderabad** | 0.1% | 19.5 ov, 5 chahiye 1 ball mein, 6 wkt |
| 2023-04-22 | Ekana (Lucknow) | Gujarat Titans 135 v Lucknow Super Giants 128 | **Gujarat Titans** | 2.5% | 14.1 ov, 30 chahiye 35 ball mein, 1 wkt |
| 2023-04-10 | Chinnaswamy (Bengaluru) | Royal Challengers Bangalore 212 v Lucknow Super Giants 213 | **Lucknow Super Giants** | 3.0% | 4.4 ov, 189 chahiye 92 ball mein, 3 wkt |

### Team ke jackpot
| Team | Match | Jackpot jeete | Jackpot haare | Net | Chase karke jeete | Defend karke jeete |
|---|---|---|---|---|---|---|
| Chennai Super Kings | 257 | 34 | 22 | +12 | 17 | 17 |
| Mumbai Indians | 283 | 42 | 30 | +12 | 18 | 24 |
| Gujarat Titans | 75 | 12 | 7 | +5 | 8 | 4 |
| Rising Pune Supergiant | 27 | 7 | 3 | +4 | 4 | 3 |
| Royal Challengers Bengaluru | 270 | 33 | 29 | +4 | 17 | 16 |
| Lucknow Super Giants | 69 | 14 | 12 | +2 | 6 | 8 |
| Kochi Tuskers Kerala | 13 | 2 | 1 | +1 | 0 | 2 |
| Punjab Kings | 262 | 32 | 33 | -1 | 13 | 19 |
| Rajasthan Royals | 242 | 28 | 30 | -2 | 19 | 9 |
| Delhi Capitals | 265 | 29 | 34 | -5 | 15 | 14 |
| Gujarat Lions | 29 | 1 | 6 | -5 | 0 | 1 |
| Kolkata Knight Riders | 257 | 28 | 33 | -5 | 12 | 16 |
| Deccan Chargers | 75 | 10 | 16 | -6 | 1 | 9 |
| Sunrisers Hyderabad | 201 | 25 | 31 | -6 | 8 | 17 |
| Pune Warriors | 45 | 2 | 12 | -10 | 0 | 2 |

- **CSK aur MI sabse zyada jackpot jeetne wali (+12 net).** CSK ya MI underdog ho to Jackpot Rule ki shart dekho.
- **SRH, KKR aur DC zyada jackpot haari (-5 se -6).** Yeh 75%+ favourite hon tab bhi stake aadhi.

### Ground ke jackpot
| Ground | Match | Jackpot | Jackpot % | Chase wale | Defend wale | Double |
|---|---|---|---|---|---|---|
| Wankhede (Mumbai) | 130 | 34 | 26.2% | 18 | 16 | 5 |
| Eden Gardens (Kolkata) | 98 | 24 | 24.5% | 13 | 11 | 3 |
| Arun Jaitley / Kotla (Delhi) | 98 | 23 | 23.5% | 10 | 13 | 5 |
| Chepauk (Chennai) | 96 | 24 | 25.0% | 7 | 17 | 2 |
| Chinnaswamy (Bengaluru) | 93 | 28 | 30.1% | 18 | 10 | 5 |
| Uppal (Hyderabad) | 86 | 21 | 24.4% | 8 | 13 | 4 |
| Sawai Mansingh (Jaipur) | 67 | 17 | 25.4% | 11 | 6 | 3 |
| PCA Mohali | 59 | 13 | 22.0% | 6 | 7 | 0 |
| Narendra Modi / Motera (Ahmedabad) | 51 | 9 | 17.6% | 5 | 4 | 0 |
| MCA / Sahara (Pune) | 51 | 14 | 27.5% | 5 | 9 | 3 |
| Dubai International Stadium | 43 | 13 | 30.2% | 5 | 8 | 3 |
| DY Patil (Navi Mumbai) | 37 | 7 | 18.9% | 2 | 5 | 2 |
| Sheikh Zayed (Abu Dhabi) | 35 | 7 | 20.0% | 3 | 4 | 1 |
| Sharjah Cricket Stadium | 28 | 7 | 25.0% | 4 | 3 | 2 |
| Brabourne (Mumbai) | 27 | 5 | 18.5% | 3 | 2 | 2 |
| Ekana (Lucknow) | 26 | 9 | 34.6% | 5 | 4 | 1 |
| Dharamsala | 18 | 3 | 16.7% | 3 | 0 | 0 |
| Mullanpur (New Chandigarh) | 17 | 5 | 29.4% | 4 | 1 | 1 |
| Visakhapatnam | 15 | 5 | 33.3% | 3 | 2 | 1 |
| Kingsmead | 14 | 7 | 50.0% | 0 | 7 | 0 |
| SuperSport Park | 11 | 2 | 18.2% | 0 | 2 | 0 |
| Holkar (Indore) | 9 | 0 | 0.0% | 0 | 0 | 0 |
| Rajkot | 9 | 1 | 11.1% | 0 | 1 | 0 |
| Raipur | 8 | 4 | 50.0% | 2 | 2 | 3 |
| New Wanderers Stadium | 8 | 4 | 50.0% | 1 | 3 | 1 |
| Barsapara (Guwahati) | 7 | 1 | 14.3% | 1 | 0 | 0 |
| Cuttack | 7 | 1 | 14.3% | 0 | 1 | 0 |
| St George's Park | 7 | 1 | 14.3% | 0 | 1 | 0 |
| Ranchi | 6 | 1 | 16.7% | 0 | 1 | 1 |
| Newlands | 5 | 2 | 40.0% | 0 | 2 | 0 |
| Kanpur | 4 | 1 | 25.0% | 1 | 0 | 0 |
| Kochi | 4 | 2 | 50.0% | 0 | 2 | 0 |
| Nagpur | 3 | 2 | 66.7% | 0 | 2 | 0 |
| De Beers Diamond Oval | 3 | 0 | 0.0% | 0 | 0 | 0 |
| Buffalo Park | 3 | 1 | 33.3% | 0 | 1 | 0 |
| OUTsurance Oval | 2 | 1 | 50.0% | 0 | 1 | 0 |

- **Ekana (35%) aur Chinnaswamy (30%) mein sabse zyada palat.** Wahan favourite par stake chhoti.
- Ahmedabad mein sirf 18%. Wahan favourite zyada bharosemand.

### Favourite kyun haarta hai (299 jackpot match)
Jab chase karne wali favourite thi aur haar gayi (161 match, average 6.6 wicket gire uske baad):

| Wajah | Match | % |
|---|---|---|
| Set batsman (30+) out hua | 124 | 77% |
| Wicket cluster (18 ball mein 3+ wicket) | 124 | 77% |
| Ek over mein 2+ wicket | 114 | 71% |
| Aakhri over ka pressure (6 ya kam run se haare) | 52 | 32% |
| Run rate ruka, wicket kam gire | 20 | 12% |

Jab defend karne wali favourite thi aur chase ne wapsi ki (138 match, sirf 1.4 wicket gire uske baad):

| Wajah | Match | % |
|---|---|---|
| Ek ya zyada over mein 18+ run | 93 | 67% |
| Death overs (16-20) mein hitting | 64 | 46% |
| Wicket nahi gire, partnership bani | 41 | 30% |
| 10+ extras diye | 21 | 15% |
| Lagatar run, RRR kaabu mein | 1 | 1% |

Palat kab shuru hua: powerplay 118, beech ke over 75, death overs 106.

| Team | Favourite ban kar haari | Sabse aam wajah |
|---|---|---|
| Delhi Capitals | 34 | Wicket cluster (18 ball mein 3+ wicket) (17), Set batsman (30+) out hua (16) |
| Kolkata Knight Riders | 33 | Set batsman (30+) out hua (17), Wicket cluster (18 ball mein 3+ wicket) (13) |
| Punjab Kings | 33 | Ek ya zyada over mein 18+ run (15), Set batsman (30+) out hua (12) |
| Sunrisers Hyderabad | 31 | Ek ya zyada over mein 18+ run (13), Set batsman (30+) out hua (13) |
| Mumbai Indians | 30 | Set batsman (30+) out hua (17), Ek over mein 2+ wicket (14) |
| Rajasthan Royals | 30 | Wicket cluster (18 ball mein 3+ wicket) (14), Ek over mein 2+ wicket (13) |
| Royal Challengers Bengaluru | 29 | Wicket cluster (18 ball mein 3+ wicket) (12), Ek ya zyada over mein 18+ run (11) |
| Chennai Super Kings | 22 | Set batsman (30+) out hua (9), Wicket cluster (18 ball mein 3+ wicket) (9) |
| Deccan Chargers | 16 | Set batsman (30+) out hua (8), Wicket cluster (18 ball mein 3+ wicket) (7) |
| Lucknow Super Giants | 12 | Ek ya zyada over mein 18+ run (8), Wicket nahi gire, partnership bani (4) |
| Pune Warriors | 12 | Wicket cluster (18 ball mein 3+ wicket) (7), Ek over mein 2+ wicket (6) |
| Gujarat Titans | 7 | Ek ya zyada over mein 18+ run (4), Aakhri over ka pressure (6 ya kam run se haare) (2) |
| Gujarat Lions | 6 | Wicket nahi gire, partnership bani (5), Ek ya zyada over mein 18+ run (4) |
| Rising Pune Supergiant | 3 | Wicket cluster (18 ball mein 3+ wicket) (3), Set batsman (30+) out hua (3) |
| Kochi Tuskers Kerala | 1 | Wicket cluster (18 ball mein 3+ wicket) (1), Ek over mein 2+ wicket (1) |

**Wicket Girne ka Jackpot Rule:** chase karne wali favourite ke 18 ball mein 3 wicket gir jayein ya set batsman (30+) out ho jaye to 77% haar wale match mein yahi hua tha. Aise waqt defend side ka odds 3.5+ ho to Jackpot Rule se defend side par chhoti bet.
**Partnership Rule:** defend karne wali favourite ke khilaf ek over mein 18+ run aaye aur wicket na gire to chase side ka chance tezi se badhta hai. Chase side par chhoti bet.

---
## 14. Playoffs aur Final
- Playoff ke 68 decided match mein chase 34 baar jeeta (50%). Final mein chase 8/18 jeeta. League mein chase 54.8%.
- Playoff mein average pehli innings 170.8.
- **Playoff Rule:** playoff mein chase ka faayda khatam ho jata hai (50%). Playoff mein form favourite 7 mein se 5 jeeta. Toss aur chase ki bajaye team ki taqat dekh kar bet chuno.

| Season | Pehle batting | Score | Chase | Score | Winner |
|---|---|---|---|---|---|
| 2026 | Gujarat Titans | 155 | Royal Challengers Bengaluru | 161 | Royal Challengers Bengaluru |
| 2025 | Royal Challengers Bengaluru | 190 | Punjab Kings | 184 | Royal Challengers Bengaluru |
| 2024 | Sunrisers Hyderabad | 113 | Kolkata Knight Riders | 114 | Kolkata Knight Riders |
| 2023 | Gujarat Titans | 214 | Chennai Super Kings | 171 | Chennai Super Kings |
| 2022 | Rajasthan Royals | 130 | Gujarat Titans | 133 | Gujarat Titans |
| 2021 | Chennai Super Kings | 192 | Kolkata Knight Riders | 165 | Chennai Super Kings |
| 2020 | Delhi Capitals | 156 | Mumbai Indians | 157 | Mumbai Indians |
| 2019 | Mumbai Indians | 149 | Chennai Super Kings | 148 | Mumbai Indians |
| 2018 | Sunrisers Hyderabad | 178 | Chennai Super Kings | 181 | Chennai Super Kings |
| 2017 | Mumbai Indians | 129 | Rising Pune Supergiant | 128 | Mumbai Indians |
| 2016 | Sunrisers Hyderabad | 208 | Royal Challengers Bangalore | 200 | Sunrisers Hyderabad |
| 2015 | Mumbai Indians | 202 | Chennai Super Kings | 161 | Mumbai Indians |
| 2014 | Kings XI Punjab | 199 | Kolkata Knight Riders | 200 | Kolkata Knight Riders |
| 2013 | Mumbai Indians | 148 | Chennai Super Kings | 125 | Mumbai Indians |
| 2012 | Chennai Super Kings | 190 | Kolkata Knight Riders | 192 | Kolkata Knight Riders |
| 2011 | Chennai Super Kings | 205 | Royal Challengers Bangalore | 147 | Chennai Super Kings |
| 2010 | Chennai Super Kings | 168 | Mumbai Indians | 146 | Chennai Super Kings |
| 2009 | Deccan Chargers | 143 | Royal Challengers Bangalore | 137 | Deccan Chargers |
| 2008 | Chennai Super Kings | 163 | Rajasthan Royals | 164 | Rajasthan Royals |

---
## 15. Odds framework aur pakke rules

### Model adjustment (calculator inko lagata hai)
Ground (chase ke liye):

| Ground | z | ~Point |
|---|---|---|
| Sawai Mansingh (Jaipur) | +0.44 | +11 |
| Holkar (Indore) | +0.43 | +11 |
| Ekana (Lucknow) | +0.31 | +8 |
| Chinnaswamy (Bengaluru) | +0.25 | +6 |
| Rajkot | +0.17 | +4 |
| Wankhede (Mumbai) | +0.10 | +3 |
| Raipur | +0.10 | +2 |
| SuperSport Park | +0.10 | +2 |
| Sharjah Cricket Stadium | +0.09 | +2 |
| Eden Gardens (Kolkata) | +0.08 | +2 |
| PCA Mohali | +0.08 | +2 |
| Visakhapatnam | +0.06 | +2 |
| Mullanpur (New Chandigarh) | +0.04 | +1 |
| Brabourne (Mumbai) | +0.04 | +1 |
| Arun Jaitley / Kotla (Delhi) | +0.01 | +0 |
| Sheikh Zayed (Abu Dhabi) | -0.02 | -1 |
| Narendra Modi / Motera (Ahmedabad) | -0.10 | -2 |
| Dharamsala | -0.10 | -2 |
| Uppal (Hyderabad) | -0.11 | -3 |
| DY Patil (Navi Mumbai) | -0.15 | -4 |
| New Wanderers Stadium | -0.15 | -4 |
| Dubai International Stadium | -0.29 | -7 |
| Chepauk (Chennai) | -0.37 | -9 |
| MCA / Sahara (Pune) | -0.39 | -10 |
| Kingsmead | -0.52 | -13 |

Team (chase karne wali ka + aur pehle batting wali ka - liya jata hai):

| Team (city) | z | ~Point |
|---|---|---|
| Gujarat Titans | +0.50 | +12 |
| Mumbai Indians | +0.26 | +6 |
| Chennai Super Kings | +0.21 | +5 |
| Royal Challengers Bengaluru | +0.10 | +3 |
| Rajasthan Royals | +0.10 | +2 |
| Sunrisers Hyderabad | +0.10 | +2 |
| Kolkata Knight Riders | +0.05 | +1 |
| Punjab Kings | +0.03 | +1 |
| Rising Pune Supergiant | -0.02 | -1 |
| Lucknow Super Giants | -0.03 | -1 |
| Gujarat Lions | -0.05 | -1 |
| Delhi Capitals | -0.06 | -2 |
| Kochi Tuskers Kerala | -0.19 | -5 |
| Deccan Chargers | -0.25 | -6 |
| Pune Warriors | -0.74 | -18 |

- **Home:** model mein asar zero (0.006), is liye calculator home ko 0 leta hai.
- **Playoff:** -0.13 (playoff mein chase thoda mushkil).

### Rules
- **Market Rule:** market aur model mein 15+ point ka farq ho to **market ke favourite par chhoti bet** (normal ka 25%). ODI/T20I mein market ke khilaf jaane par nuksaan hua.
- **Jackpot Rule:** underdog ka odds 3.5+ ho aur model usay market se 7+ point zyada de to underdog par chhoti bet (normal ka 20-25%).
- **Value Rule:** model kisi team ko market se 5-14 point zyada de to us team par bet.
- **Favourite Rule:** farq 5 point se kam ho to dono ke favourite par bet.
- **185 Line Rule:** 185 tak target = chase side, 186-200 = calculator, 201+ = defend side (section 2).
- **Toss Rule:** toss jeet kar field karne wali 59-60% (section 3).
- **Home Rule:** IPL mein ghar ka faayda nahi (section 4).
- **Delhi Kotla Rule, Chepauk Rule, Chinnaswamy Rule, Ekana Rule, Uppal Rule, Ahmedabad Rule** (section 5).
- **RCB Rule, LSG Defend Rule, MI Defend Rule** (section 6).
- **Head-to-Head Rule** (section 7).
- **Favourite Bat First Rule** (section 8).
- **Powerplay Rule:** chase 6 over par 3+ wicket = 25% (section 10).
- **Wicket Girne ka Jackpot Rule, Partnership Rule** (section 13).
- **Playoff Rule** (section 14).
- **Aakhri Over Rule** (section 9).
- **Stake Rule:** 25 paisa se kam ke favourite par stake normal se zyada kabhi mat lagao. IPL mein 4 mein se 1 match palat jata hai (2026 mein 3 mein se 1).

### Market log (har match ke baad bharna hai)
| Date | Match | Haalat | Market | Model | Bet | Natija |
|---|---|---|---|---|---|---|

---
## 16. Limits
- Har season mein har team ke sirf 14-17 match hote hain, is liye "2025 se" wale team numbers 25-30 match par hain.
- Impact Player daur sirf 4 season ka hai (282 decided match).
- Data mein squad, injury, pitch report aur dew nahi. Yeh base rate hai, guarantee nahi.
